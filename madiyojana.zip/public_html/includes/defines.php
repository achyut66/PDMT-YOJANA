<?php
defined("DS")? NULL : define('DS','/');
defined("KEYID")? NULL : define('KEYID','21232f297a57a5a743894a0e4a801fc3brt123tarak_auth_id');
defined("KEYMODE")? NULL : define('KEYMODE','21232f297a57a5a743894a0e4a801fc3brt123tarak_mode');
defined("SITE_ROOT")? NULL : define('SITE_ROOT',$_SERVER['DOCUMENT_ROOT'].DS);
defined("LIB_INCLUDE")? NULL : define('LIB_INCLUDE',SITE_ROOT.'includes'.DS);
defined("MENU_INCLUDES")? NULL : define('MENU_INCLUDES',SITE_ROOT.'menuincludes'.DS);
defined("SITE_NAME")? NULL : define('SITE_NAME','माडी नगरपालिका  ');
defined("SITE_FIRST_NAME")? NULL : define('SITE_FIRST_NAME','माडी नगरपालिका  ');
defined("SITE_TYPE")? NULL : define('SITE_TYPE','नगरपालिका');
defined("SITE_LOCATION")? NULL : define('SITE_LOCATION','माडी  नगरपालिका');
defined("SITE_ADDRESS")? NULL : define('SITE_ADDRESS','बसन्तपुर,चितवन');
defined("SITE_HEADING")? NULL : define('SITE_HEADING','नगर कार्यपालिकाको कार्यालय');
defined("SITE_SUBHEADING")? NULL : define('SITE_SUBHEADING','Madi Municipality ');
defined("SITE_SECONDSUBHEADING")? NULL: define('SITE_SECONDSUBHEADING', 'बाग्मती प्रदेश, नेपाल');
defined("SITE_SUBADDRESS")? NULL : define('SITE_SUBADDRESS','नं वडा कार्यलय');;
defined("SITE_OFFICE")? NULL : define('SITE_OFFICE','BMS');
defined("SITE_DISTRICT")? NULL : define('SITE_DISTRICT','चितवन');
defined("SITE_OFFICE_WEB")? NULL : define('SITE_OFFICE_WEB','http://bmsnepal.net');
defined("SITE_ZONE")? NULL : define('SITE_ZONE','चितवन');
defined("SITE_SAMITI")? NULL : define('SITE_SAMITI','उपभोक्ता समिति ');
defined("SITE_SAASTHA")? NULL : define('SITE_SAASTHA','संस्था/समिति ');
defined("STARIY")? NULL : define('STARIY','नगर');
defined("SITE_DESC")? NULL : define('SITE_DESC','न.पा.');
?>
