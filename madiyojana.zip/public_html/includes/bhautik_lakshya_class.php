<?php
// if it's going to need the database, then it's
// probably smart to require it before we start
require_once ('database.php');
require_once ('database_object.php');
class Bhautik_lakshya
{
	protected static $table_name = "bhautik_lakshya";
	protected static $db_fields = array(
		'id',
		'parent_id',
		'details_id',
		'qty',
		'unit_id',
		'plan_id',
		'type',
		'prev_qty',
		'payment_count',
		'miti',
		'miti_english',
		'is_heavy'
	);
	public $id;
	public $parent_id;
	public $details_id;
	public $qty;
	public $unit_id;
	public $plan_id;
	public $type;
	public $prev_qty;
	public $payment_count;
	public $miti;
	public $miti_english;
	public $is_heavy;
	// Common database method{
	public static function sum_qty_by_plan_id_detail_id_type($id = 0, $detail_id, $type)
	{
		global $database;
		$sql = "select sum(qty) from " . self::$table_name . " where plan_id={$id} and details_id={$detail_id} and type={$type}";
		//                echo $sql."<br>";
		$result_set = $database->query($sql);
		$row = $database->fetch_array($result_set);
		return array_shift($row);

	}
	public static function get_report_data($parent_id)
	{
		global $database;
		$sql = "SELECT t1.details_id,t1.unit_id,prev_qty,t1.plan_id,t1.type,sum(t1.qty) as 'total_qty',t2.name as 'tname' FROM bhautik_lakshya t1 left join setting_bhautik_pariman t2 on t2.id = t1.details_id WHERE t1.details_id =" . $parent_id . " group by t1.details_id";
		$result_set = $database->query($sql);
		$row = $database->fetch_all($result_set);
		return array_shift($row);

	}
	public static function get_plan_id_from_parent_id_type1($parent_id, $plan_ids)
	{
		global $database;
		$result_array = self::find_by_sql("select distinct plan_id from " . self::$table_name . " where plan_id IN ({$plan_ids}) and parent_id={$parent_id} and type=1");
		return $result_array;
	}
	public static function find_by_plan_id_detail_id_type($id = 0, $detail_id, $type)
	{
		global $database;
		$result_array = self::find_by_sql("select * from " . self::$table_name . " where plan_id={$id} and details_id={$detail_id} and type={$type}");
		return !empty($result_array) ? array_shift($result_array) : false;
	}
	public static function find_by_plan_id_and_date($id = 0, $date_from, $date_to)
	{
		global $database;
		$result_array = self::find_by_sql("select * from " . self::$table_name . " where plan_id={$id} and miti_english > '" . $date_from . "' and miti_english< '" . $date_to . "'");
		return $result_array;
	}
	public static function find_all()
	{
		global $database;
		return self::find_by_sql("select * from " . self::$table_name);

	}
	public static function group_all()
	{
		global $database;
		return self::find_by_sql("select parent_id, details_id, sum(qty) as qty, unit_id, sum(prev_qty) as prev_qty from " . self::$table_name . " group by details_id");

	}
	public static function setEmptyObjects()
	{
		return new self;
	}
	public function getName($string_id = "")
	{
		$topic_selected = self::find_by_id($string_id);
		return $topic_names = $topic_selected->name;
	}
	public static function find_by_filename($filename)
	{
		global $database;
		$result_array = self::find_by_sql("select * from " . self::$table_name . " where link_name='" . $filename . "' limit 1");
		return !empty($result_array) ? array_shift($result_array) : false;
	}
	public static function find_by_plan_id_and_type_payment_count($id = 0, $type, $payment_count)
	{
		global $database;
		$result_array = self::find_by_sql("select * from " . self::$table_name . " where plan_id={$id} and type=2 and payment_count=" . $payment_count);
		return $result_array;
	}
	public static function find_by_plan_id_and_type($plan_id = 0, $type)
	{
		global $database;
		$result_array = self::find_by_sql("select * from " . self::$table_name . " where plan_id IN ({$plan_id}) and type={$type}");
		return $result_array;
	}
	public static function find_by_plan_id_and_type_new($plan_id = 0, $type)
	{
		global $database;
		$result_array = self::find_by_sql("select distinct plan_id from " . self::$table_name . " where plan_id IN ({$plan_id}) and type={$type}");
		return $result_array;
	}
	public static function find_by_id($id = 0)
	{
		global $database;
		$result_array = self::find_by_sql("select * from " . self::$table_name . " where id={$id} limit 1");
		return !empty($result_array) ? array_shift($result_array) : false;
	}
	public static function find_by_pan_no($pan_no = 0)
	{
		global $database;
		$result_array = self::find_by_sql("select * from " . self::$table_name . " where pan_no={$pan_no} limit 1");
		return !empty($result_array) ? array_shift($result_array) : false;
	}
	public static function find_by_sql($sql = "")
	{
		global $database;
		$result_set = $database->query($sql);
		$object_array = array();
		while ($row = $database->fetch_array($result_set)) {
			$object_array[] = self::instantiate($row);
		}
		return $object_array;
	}
	public static function count_all()
	{
		global $database;
		$sql = "select count(*) from " . self::$table_name;
		$result_set = $database->query($sql);
		$row = $database->fetch_array($result_set);
		return array_shift($row);
	}
	public static function count_by_detail_id($id)
	{
		global $database;
		$sql = "select count(*) from " . self::$table_name . " where detail_id=" . $id;
		$result_set = $database->query($sql);
		$row = $database->fetch_array($result_set);
		return array_shift($row);
	}

	public function savePostData($post, $clause)
	{
		foreach (self::$db_fields as $db_field) {
			if ($clause == "create" && $db_field == "id") {
				continue;
			}
			if (property_exists($this, $db_field)) {
				$this->$db_field = $post[$db_field];
			}
		}

		return $this->save();
	}
	private static function instantiate($record)
	{
		// could check that $record exists and is an array
		// simple, long form approach
		$object = new self;
		/* $object->id			= $record['id'];
																																							   $object->username		= $record['username'];
																																							   $object->password 		= $record['password'];
																																							   $object->first_name 	= $record['first_name'];
																																							   $object->last_name 	= $record['last_name'];*/


		// more dynamic, short-form approach:
		foreach ($record as $attribute => $value) {
			if ($object->has_attribute($attribute)) {
				$object->$attribute = $value;
			}
		}
		return $object;
	}

	private function has_attribute($attribute)
	{
		// get_object_vars returns an associative array with all attributes
		// (incl. private ones!) as the keys and their current values as the value
		$object_vars = get_object_vars($this);
		// we don't care about the value, we just want to know if the key exists
		// will return true or false
		return array_key_exists($attribute, $object_vars);
	}
	protected function attributes()
	{
		// return an array of attribute keys and their values
		$attributes = array();
		foreach (self::$db_fields as $field) {
			if (property_exists($this, $field)) {
				$attributes[$field] = $this->$field;
			}
		}
		return $attributes;
	}
	protected function sanitized_attributes()
	{
		global $database;
		$clean_attributes = array();
		// sanitize the values before submitting
		// note: does not alter the actual value of each attribute
		foreach ($this->attributes() as $key => $value) {
			$clean_attributes[$key] = $database->escape_value($value);
		}
		return $clean_attributes;
	}
	public function save()
	{
		// a new record won't have an id yet
		return isset($this->id) ? $this->update() : $this->create();
	}
	public function create()
	{
		global $database;
		// dont forget sql syntax and good habits
		// insert into table ('key', 'key') values ('value', 'value')
		// single quotes around all values
		// escape all values to prevent sql injection
		$attributes = $this->sanitized_attributes();
		$sql = "insert into " . self::$table_name . "(";
		$sql .= join(",", array_keys($attributes));
		$sql .= ") values ('";
		$sql .= join("', '", array_values($attributes));
		$sql .= "')";
		if ($database->query($sql)) {
			$this->id = $database->insert_id();
			return true;
		} else {
			return false;
		}
	}

	public function update()
	{
		global $database;
		$attributes = $this->sanitized_attributes();
		$attribute_pairs = array();
		foreach ($attributes as $key => $value) {
			$attribute_pairs[] = "{$key}='{$value}'";
		}
		$sql = "update " . self::$table_name . " set ";
		$sql .= join(", ", $attribute_pairs);
		$sql .= "where id=" . $database->escape_value($this->id);
		$database->query($sql);
		return ($database->affected_rows() == 1) ? true : false;
	}


	public function delete_all_by_plan_id($plan_id)
	{
		global $database;
		// delete from table where condition limit 1
		$sql = "delete from " . self::$table_name;
		$sql .= " where plan_id=" . $database->escape_value($plan_id);
		$database->query($sql);
		return ($database->affected_rows() == 1) ? true : false;
	}


	public function delete()
	{
		global $database;
		// delete from table where condition limit 1
		$sql = "delete from " . self::$table_name;
		$sql .= " where id=" . $database->escape_value($this->id);
		$sql .= " limit 1";
		$database->query($sql);
		return ($database->affected_rows() == 1) ? true : false;
	}
	public function getSubDataJoin($parent_id)
	{
		global $database;
		$sql = "select t1.* from bhautik_lakshya t1 
		inner join setting_bhautik_pariman t2 on t1.parent_id = t2.id
		inner join plan_total_investment t3 on t1.plan_id = t3.plan_id
		where t1.parent_id =" . $parent_id;
		$result_set = $database->query($sql);
		$array = array();
		while ($row = mysqli_fetch_assoc($result_set)) {
			$array[] = $row;
		}
		return $array;
	}
	public function getBhautikData()
	{
		global $database;
		$sql = 'select parent_id,count(parent_id) from bhautik_lakshya group by parent_id';
		$result_set = $database->query($sql);
		$array = array();
		while ($row = mysqli_fetch_assoc($result_set)) {
			$array[] = $row;
		}
		return $array;

	}

	public function count_bhautik_plans($parent_id)
	{
		global $database;
		$sql = "select plan_id, count(plan_id) from(bhautik_lakshya) where parent_id = '" . $parent_id . "' group by plan_id";
		$result_set = $database->query($sql);
		$row = $database->fetch_array($result_set);
		return array_shift($row);

	}
	// upabhokta marfat ko yojana ko lagi
	public function getDetailsBhautik($details_id, $plan_id = NULL)
	{
		global $database;
		$sql = "select sum(qty) as total_qty from bhautik_lakshya where type=1";
		if (!empty($details_id)) {
			$sql .= " and details_id ='" . $details_id . "'";
		}
		if (!empty($plan_id)) {
			$sql .= " and plan_id ='" . $plan_id . "'";
		}
		$sql .= "limit 1";
		$result_set = $database->query($sql);
		$row = $database->fetch_array($result_set);
		return array_shift($row);
	}
	// samiti marfat ko yojana ko lagi 
// functions end
// upabhokta marfat pragati
	public function getDetailsBhautikPragati($details_id, $plan_id = NULL)
	{
		global $database;
		$sql = "select sum(qty) as total_qty from bhautik_lakshya where type <> 1";

		$sql .= " and details_id ='" . $details_id . "'";

		if (!empty($plan_id)) {
			$sql .= " and plan_id ='" . $plan_id . "'";
		}
		$sql .= "limit 1";

		$result_set = $database->query($sql);
		$row = $database->fetch_array($result_set);
		return array_shift($row);
	}
	// samiti marfat pragati

	//getPlanID
	public function getPlanID($details_id)
	{
		global $database;
		$sql = "select distinct plan_id  from bhautik_lakshya where details_id = '" . $details_id . "'";
		$result_set = $database->query($sql);
		$array = array();
		while ($row = mysqli_fetch_assoc($result_set)) {
			$array[] = $row;
		}
		return $array;
	}

}
?>