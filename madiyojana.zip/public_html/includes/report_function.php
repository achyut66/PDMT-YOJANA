<?php
//include_once 'includes/functions.php';
error_reporting(0);
function get_type_nepali($type)
{
    if ($type == 0) {
        $output = "योजनाहरु";
    } else {
        $output = "कार्यक्रमहरु";
    }
    return $output;
}
function get_net_total_amount_sum_for_all_programs($ward)
{
    global $database;
    $sql = "select SUM(a.net_total_amount) from program_payment_final as a INNER JOIN plan_details1 as b on a.program_id=b.id where b.ward_no=" . $ward;
    $result_set = $database->query($sql);
    $row = $database->fetch_array($result_set);
    $total = array_shift($row);
    if (empty($total)) {
        $total = 0;
    }
    return $total;

}
function get_total_payment_amount_for_all_programs($ward)
{
    global $database;
    $sql = "select SUM(a.payment_amount) from program_payment as a INNER JOIN plan_details1 as b on a.program_id=b.id where b.ward_no=" . $ward;
    $result_set = $database->query($sql);
    $row = $database->fetch_array($result_set);
    $total = array_shift($row);
    if (empty($total)) {
        $total = 0;
    }
    return $total;
}
function get_wardwise_result_sql($ward, $table)
{
    global $database;
    $array = array();
    $sql = "select * from " . $table . " as a LEFT JOIN plan_details1 as b on a.plan_id = b.id where b.ward_no=" . $ward;
    $result = $database->query($sql);
    while ($obj = mysqli_fetch_object($result)) {
        array_push($array, $obj);
    }
    return $array;
}
function get_wardwise_result_sql_program($ward, $table)
{
    global $database;
    $array = array();
    $sql = "select * from " . $table . " as a LEFT JOIN plan_details1 as b on a.program_id = b.id where b.ward_no=" . $ward;
    //    echo $sql;exit;
    $result = $database->query($sql);
    while ($obj = mysqli_fetch_object($result)) {
        array_push($array, $obj);
    }
    //    echo "<pre>";
//    print_r($array);
//    echo "</pre>";exit;
    return $array;
}
function get_wardwise_result_sql_program_unique($ward, $table)
{
    global $database;
    $array = array();
    $sql = "SELECT a.*, b.*
            FROM (
                SELECT DISTINCT program_id
                FROM " . $table . " AS a
                LEFT JOIN plan_details1 AS b ON a.program_id = b.id 
                WHERE b.ward_no = " . $ward . "
            ) AS distinct_programs
            LEFT JOIN " . $table . " AS a ON distinct_programs.program_id = a.program_id
            LEFT JOIN plan_details1 AS b ON a.program_id = b.id 
            WHERE b.ward_no = " . $ward;

    $result = $database->query($sql);
    while ($obj = mysqli_fetch_object($result)) {
        array_push($array, $obj);
    }
    return $array;
}

function get_wardwise_result_sql_program_un($ward, $table)
{
    global $database;
    $unique_program = null;

    $sql = "SELECT a.* FROM " . $table . " AS a
          LEFT JOIN plan_details1 AS b ON a.program_id = b.id
          WHERE b.ward_no = " . $ward . "
          AND b.sn = 1
          LIMIT 1";  // Limit to 1 row

    $result = $database->query($sql);

    if ($row = mysqli_fetch_assoc($result)) {
        $unique_program = $row;
    }

    mysqli_free_result($result);

    return $unique_program;
}




function get_final_payed_program($ward)
{
    $final_array = array();
    $array = get_final_paid_program_ids($ward);
    $result_array = $array["selected_id"];
    //    print_r($result_array);exit;
    foreach ($result_array as $data) {
        $max_count = Programpaymentfinal::getMaxIds($data);
        //        echo $max_count;exit;
        $final_data = Programpaymentfinal::find_by_program_id_and_sn($data, $max_count);
        array_push($final_array, $final_data->id);
    }
    //    print_r($final_array);exit;
    return $final_array;
}
function Get_empty_plan($ward)
{
    if (empty($ward)) {
        $sql = "select id from plan_details1 where type=0";
    } else {
        $sql = "select id from plan_details1 where type=0 and ward_no=" . $ward;
    }

    $all_plans = Plandetails1::find_by_sql($sql);
    $empty_array = array();
    foreach ($all_plans as $plan) {
        $more_plan_details = Moreplandetails::find_by_plan_id($plan->id);
        $plan_total_investment = Plantotalinvestment::find_by_plan_id($plan->id);
        $samiti_total_investment = Samitiplantotalinvestment::find_by_plan_id($plan->id);
        $contract_total_investment = Contractinfo::find_by_plan_id($plan->id);
        $amanat_total_investment = Amanatlagat::find_by_plan_id($plan->id);
        $quotation_total_investment = Quotationtotalinvestment::find_by_plan_id($plan->id);
        $ethekka_total_investment = Ethekka_lagat::find_by_plan_id($plan->id);
        if (empty($contract_total_investment) && empty($samiti_total_investment) && empty($more_plan_details) && empty($amanat_total_investment) && empty($quotation_total_investment) && empty($ethekka_total_investment)) {
            array_push($empty_array, $plan->id);
        }
    }

    return $empty_array;

}
function Samiti_plan($ward)
{
    if (empty($ward)) {
        $all_plans = Samitiplantotalinvestment::find_all();
    } else {
        $all_plans = get_wardwise_result_sql($ward, "samiti_plan_total_investment");
    }


    $samiti_count = 0;
    $samiti_count_array = array();

    $samiti_more_details_count = 0;
    $samiti_more_details_array = array();

    $advance_count = 0;
    $advance_count_array = array();

    $analysis_count = 0;
    $analysis_count_array = array();

    $final_count = 0;
    $final_count_array = array();

    foreach ($all_plans as $plan) {
        $samiti_more_details = Samitimoreplandetails::find_by_plan_id($plan->plan_id);
        $advance = Planstartingfund::find_by_plan_id($plan->plan_id);
        $analysis = Analysisbasedwithdraw::find_by_plan_id($plan->plan_id);
        $final = Samitiplanamountwithdrawdetails::find_by_plan_id($plan->plan_id);

        if (!empty($samiti_more_details)) {

            if (empty($advance) && empty($analysis) && empty($final)) {
                $samiti_more_details_count++;
                array_push($samiti_more_details_array, $plan->plan_id);
            }
        }

        if (!empty($advance)) {
            if (empty($analysis) && empty($final)) {
                $advance_count++;
                array_push($advance_count_array, $plan->plan_id);
            }
        }
        if (!empty($analysis)) {
            if (empty($final)) {
                $analysis_count++;
                array_push($analysis_count_array, $plan->plan_id);
            }
        }
        if (!empty($final)) {
            $final_count++;
            array_push($final_count_array, $plan->plan_id);
        }

    }
    //      echo "<pre>"; print_r($samiti_more_details_array); echo "</pre>";exit;
    $result["samiti_count_array"] = $samiti_count_array;
    $result["advance_count_array"] = $advance_count_array;
    $result["analysis_count_array"] = $analysis_count_array;
    $result["final_count_array"] = $final_count_array;
    $result["samiti_more_details_array"] = $samiti_more_details_array;
    $result["samiti_count"] = $samiti_count;
    $result["advance_count"] = $advance_count;
    $result["analysis_count"] = $analysis_count;
    $result["final_count"] = $final_count;
    $result["samiti_more_details_count"] = $samiti_more_details_count;
    return $result;
}
// quotation total investment and related other quotation forms
function Quotation_invest($ward)
{
    if (empty($ward)) {
        $all_plans = Quotationtotalinvestment::find_all();
    } else {
        $all_plans = get_wardwise_result_sql($ward, "quotation_total_investment");
    }
    // echo "<pre>";
    // print_r($all_plans);
    // die;
    $result = array();
    $quotation_count = 0;
    $quotation_count_array = array();

    $quotation_more_details_count = 0;
    $quotation_more_details_array = array();

    $quotation_advance_count = 0;
    $quotation_advance_count_array = array();

    $quotation_analysis_count = 0;
    $quotation_analysis_count_array = array();

    $quotation_final_count = 0;
    $quotation_final_count_array = array();

    foreach ($all_plans as $plan) {

        $quotation_more_details = Quotationmoredetails::find_by_plan_id($plan->plan_id);
        $advance = Planstartingfund::find_by_plan_id($plan->plan_id);
        $analysis = Analysisbasedwithdraw::find_by_plan_id($plan->plan_id);
        $final = Planamountwithdrawdetails::find_by_plan_id($plan->plan_id);

        if (!empty($quotation_more_details)) {

            if (empty($advance) && empty($analysis) && empty($final)) {
                $quotation_more_details_count++;
                array_push($quotation_more_details_array, $plan->plan_id);
            }
        }
        //  pp($quotation_more_details_array);
        if (!empty($advance)) {
            if (empty($analysis) && empty($final)) {
                $quotation_advance_count++;
                array_push($quotation_advance_count_array, $plan->plan_id);
            }
        }
        if (!empty($analysis)) {
            if (empty($final)) {
                $quotation_analysis_count++;
                array_push($quotation_analysis_count_array, $plan->plan_id);
            }
        }
        if (!empty($final)) {
            $quotation_final_count++;
            array_push($quotation_final_count_array, $plan->plan_id);
        }

    }
    //  echo "<pre>"; print_r($quotation_more_details_array); //echo "</pre>";exit;
    $result["quotation_count_array"] = $quotation_count_array;
    $result["quotation_advance_count_array"] = $quotation_advance_count_array;
    $result["quotation_analysis_count_array"] = $quotation_analysis_count_array;
    $result["quotation_final_count_array"] = $quotation_final_count_array;
    $result["quotation_more_details_array"] = $quotation_more_details_array;
    $result["quotation_count"] = $quotation_count;
    $result["quotation_advance_count"] = $quotation_advance_count;
    $result["quotation_analysis_count"] = $quotation_analysis_count;
    $result["quotation_final_count"] = $quotation_final_count;
    $result["quotation_more_details_count"] = $quotation_more_details_count;
    // echo "<pre>";
    // print_r($result);
    // die;
    return $result;
}

// end of quotation
// e-thekka sanchalan
function Ethekka_invest($ward)
{
    if (empty($ward)) {
        $all_plans = Ethekka_lagat::find_all();
    } else {
        $all_plans = get_wardwise_result_sql($ward, "ethekka_kul_lagat");
    }
    // echo "<pre>";
    // print_r($all_plans);
    // die;
    $result = array();
    $ethekka_count = 0;
    $ethekka_count_array = array();

    $ethekka_more_detail_count = 0;
    $ethekka_more_details_array = array();

    $ethekka_advance_count = 0;
    $ethekka_advance_count_array = array();

    $ethekka_analysis_count = 0;
    $ethekka_analysis_count_array = array();

    $ethekka_final_count = 0;
    $ethekka_final_count_array = array();

    foreach ($all_plans as $plan) {

        $quotation_more_details = Ethekkainfo::find_by_plan_id($plan->plan_id);
        $advance = Planstartingfund::find_by_plan_id($plan->plan_id);
        $analysis = Analysisbasedwithdraw::find_by_plan_id($plan->plan_id);
        $final = Planamountwithdrawdetails::find_by_plan_id($plan->plan_id);

        if (!empty($quotation_more_details)) {

            if (empty($advance) && empty($analysis) && empty($final)) {
                $ethekka_more_detail_count++;
                array_push($ethekka_more_details_array, $plan->plan_id);
            }
        }
        //  pp($ethekka_more_details_array);
        if (!empty($advance)) {
            if (empty($analysis) && empty($final)) {
                $ethekka_advance_count++;
                array_push($ethekka_advance_count_array, $plan->plan_id);
            }
        }
        if (!empty($analysis)) {
            if (empty($final)) {
                $ethekka_analysis_count++;
                array_push($ethekka_analysis_count_array, $plan->plan_id);
            }
        }
        if (!empty($final)) {
            $ethekka_final_count++;
            array_push($ethekka_final_count_array, $plan->plan_id);
        }

    }
    //  echo "<pre>"; print_r($ethekka_more_details_array); //echo "</pre>";exit;
    $result["ethekka_count_array"] = $ethekka_count_array;
    $result["ethekka_advance_count_array"] = $ethekka_advance_count_array;
    $result["ethekka_analysis_count_array"] = $ethekka_analysis_count_array;
    $result["ethekka_final_count_array"] = $ethekka_final_count_array;
    $result["ethekka_more_details_array"] = $ethekka_more_details_array;
    $result["ethekka_count"] = $ethekka_count;
    $result["ethekka_advance_count"] = $ethekka_advance_count;
    $result["ethekka_analysis_count"] = $ethekka_analysis_count;
    $result["ethekka_final_count"] = $ethekka_final_count;
    $result["ethekka_more_detail_count"] = $ethekka_more_detail_count;
    // echo "<pre>";
    // print_r($result);
    // die;
    return $result;
}
// print_r($result);
// die;
// end of quotation
function Contract_plans($ward)
{

    if (empty($ward)) {
        $all_plans = Contract_total_investment::find_all();
    } else {
        $all_plans = get_wardwise_result_sql($ward, "contract_total_investment");
    }
    $contract_count = 0;
    $contract_count_array = array();


    $contract_more_details_count = 0;
    $contract_more_details_array = array();

    $contract_advance_count = 0;
    $contract_advance_array = array();

    $contract_anlaysis_count = 0;
    $contract_analysis_array = array();

    $contract_final_count = 0;
    $contract_final_array = array();



    $contract_total_investment_count = 0;
    $contract_total_investment_array = array();
    foreach ($all_plans as $plan) {
        // print_r($plan);exit;
        $contract_more_details = Contractmoredetails::find_by_plan_id($plan->plan_id);
        $contract_advance = Contractstartingfund::find_by_plan_id($plan->plan_id);
        $contract_analysis = Contractanalysisbasedwithdraw::find_by_plan_id($plan->plan_id);
        $contract_final = Contractamountwithdrawdetails::find_by_plan_id($plan->plan_id);
        $contract_total_investment = Contract_total_investment::find_by_plan_id($plan->plan_id);

        if (!empty($contract_total_investment)) {
            array_push($contract_total_investment_array, $plan->plan_id);
            $contract_total_investment_count++;
        }
        if (!empty($contract_more_details)) {

            if (empty($contract_advance) && empty($contract_analysis) && empty($contract_final)) {
                $contract_more_details_count++;
                array_push($contract_more_details_array, $plan->plan_id);
            }
        } else {
            array_push($contract_count_array, $plan->plan_id);
            $contract_count++;
        }

        if (!empty($contract_advance)) {
            if (empty($contract_analysis) && empty($contract_final)) {
                $contract_advance_count++;
                array_push($contract_advance_array, $plan->plan_id);
            }
        }
        if (!empty($contract_analysis)) {
            if (empty($contract_final)) {
                $contract_anlaysis_count++;
                array_push($contract_analysis_array, $plan->plan_id);
            }
        }
        if (!empty($contract_final)) {
            $contract_final_count++;
            array_push($contract_final_array, $plan->plan_id);
        }


    }
    //             echo "<pre>"; print_r($contract_more_details_array);echo "</pre>";exit;
    $result["contract_count"] = $contract_count;
    $result["contract_more_details_count"] = $contract_more_details_count;
    $result["contract_advance_count"] = $contract_advance_count;
    $result["contract_analysis_count"] = $contract_anlaysis_count;
    $result["contract_final_count"] = $contract_final_count;
    $result["contract_count_array"] = $contract_count_array;
    $result["contract_advance_array"] = $contract_advance_array;
    $result["contract_analysis_array"] = $contract_analysis_array;
    $result["contract_final_array"] = $contract_final_array;
    $result["contract_more_details_array"] = $contract_more_details_array;
    // print_r($result["contract_advance_array"]);
    // die;
    return $result;
}
function get_amanat_plan_id($ward)
{
    if (empty($ward)) {
        $all_plans = AmanatLagat::find_all();
    } else {
        $all_plans = get_wardwise_result_sql($ward, "amanat_lagat");
    }


    $result = array();
    $count = 0;
    $count_array = array();

    $more_detail_count = 0;
    $more_detail_count_array = array();

    $advance_count = 0;
    $advance_count_array = array();

    $analysis_count = 0;
    $analysis_count_array = array();

    $final_count = 0;
    $final_count_array = array();

    $my_count = 0;
    foreach ($all_plans as $plan) {
        $total_investment_filled_plans = AmanatLagat::find_by_plan_id($plan->plan_id);
        $more_plan_details = Amanat_more_details::find_by_plan_id($plan->plan_id);
        $advance = Planstartingfund::find_by_plan_id($plan->plan_id);
        $analysis = Analysisbasedwithdraw::find_by_plan_id($plan->plan_id);
        $final = Planamountwithdrawdetails::find_by_plan_id($plan->plan_id);
        if (!empty($total_investment_filled_plans)) {

            if (empty($advance) && empty($analysis) && empty($final)) {
                $more_detail_count++;
                array_push($more_detail_count_array, $plan->plan_id);
            }
        } else {
            array_push($count_array, $plan->plan_id);
            $count++;
        }

        if (!empty($advance)) {
            if (empty($analysis) && empty($final)) {
                $advance_count++;
                array_push($advance_count_array, $plan->plan_id);
            }
        }
        if (!empty($analysis)) {
            if (empty($final)) {
                $analysis_count++;
                array_push($analysis_count_array, $plan->plan_id);
            }
        }
        if (!empty($final)) {
            $final_count++;
            array_push($final_count_array, $plan->plan_id);
        }
    }
    $result["count_array"] = $count_array;
    $result["advance_count_array"] = $advance_count_array;
    $result["analysis_count_array"] = $analysis_count_array;
    $result["final_count_array"] = $final_count_array;
    $result["more_detail_count_array"] = $more_detail_count_array;
    $result["count"] = $count;
    $result["advance_count"] = $advance_count;
    $result["analysis_count"] = $analysis_count;
    $result["final_count"] = $final_count;
    $result["more_detail_count"] = $more_detail_count;
    return $result;
}

function getOnlyRegisteredPlans($ward = "")
{
    $samiti = Samiti_plan($ward);
    $contract = Contract_plans($ward);
    $amanat = get_amanat_plan_id($ward);
    $quotation = Quotation_invest($ward);
    $ethekka = Ethekka_invest($ward);

    //    echo "samiti_final_count:=".$samiti['final_count']."and contraact_final_count:=".$data['contract_final_count'];exit;
    $check_array = array();
    //    $sql = "select id from plan_details1 where type=0";
    if (empty($ward)) {
        $all_plans = Plantotalinvestment::find_all();
    } else {
        $all_plans = get_wardwise_result_sql($ward, "plan_total_investment");
    }
    // print_r($samiti);
    // die;

    $result = array();
    $count = 0;
    $count_array = array();

    $customer_count0 = 0;
    $customer_count0_array = array();

    $customer_count = 0;
    $customer_count_array = array();

    $more_detail_count = 0;
    $more_detail_count_array = array();
    $public_count = 0;

    $advance_count = 0;
    $advance_count_array = array();

    $analysis_count = 0;
    $analysis_count_array = array();

    $final_count = 0;
    $final_count_array = array();

    $my_count = 0;
    foreach ($all_plans as $plan) {
        $total_investment_filled_plans = Plantotalinvestment::find_by_plan_id($plan->plan_id);
        $customer_details0 = Costumerassociationdetails0::find_by_plan_id($plan->plan_id);
        $customer_details = Costumerassociationdetails::find_by_plan_id($plan->plan_id);
        $public_details = Publicinvestigationdetails::find_by_plan_id($plan->plan_id);
        $more_plan_details = Moreplandetails::find_by_plan_id($plan->plan_id);
        $advance = Planstartingfund::find_by_plan_id($plan->plan_id);
        $analysis = Analysisbasedwithdraw::find_by_plan_id($plan->plan_id);
        $final = Planamountwithdrawdetails::find_by_plan_id($plan->plan_id);

        $contract_total_investment = Contract_total_investment::find_by_plan_id($plan->plan_id);
        $samiti_total_investment = Samitiplantotalinvestment::find_by_plan_id($plan->plan_id);
        //  pp($more_plan_details);
        if (!empty($more_plan_details)) {

            if (empty($advance) && empty($analysis) && empty($final)) {
                $more_detail_count++;
                array_push($more_detail_count_array, $plan->plan_id);
            }
        } else {
            array_push($count_array, $plan->plan_id);
            $count++;
        }

        if (!empty($advance)) {
            if (empty($analysis) && empty($final)) {
                $advance_count++;
                array_push($advance_count_array, $plan->plan_id);
            }
        }
        if (!empty($analysis)) {
            if (empty($final)) {
                $analysis_count++;
                array_push($analysis_count_array, $plan->plan_id);
            }
        }
        if (!empty($final)) {
            $final_count++;
            array_push($final_count_array, $plan->plan_id);
        }
    }
    $empty_array = Get_empty_plan($ward);
    $total_more_details_count = $more_detail_count + $samiti["samiti_more_details_count"] + $contract['contract_more_details_count'] + $amanat['more_detail_count'] + $quotation['quotation_more_details_count'] + $ethekka['ethekka_more_detail_count'];
    $total_advance_count = $advance_count + $samiti['advance_count'] + $contract['contract_advance_count'] + $amanat['advance_count'] + $quotation['quotation_advance_count'] + $ethekka['ethekka_advance_count'];
    $total_analysis_count = $analysis_count + $samiti['analysis_count'] + $contract['contract_analysis_count'] + $amanat['analysis_count'] + $quotation['quotation_analysis_count'] + $ethekka['ethekka_analysis_count'];
    $total_final_count = $final_count + $samiti['final_count'] + $contract['contract_final_count'] + $amanat['final_count'] + $quotation['quotation_final_count'] + $ethekka['ethekka_final_count'];
    // echo "<pre>";
    // print_r($amanat['more_detail_count']);
    // die;
    $total_more_details_array = array();
    $total_advance_array = array();
    $total_analysis_array = array();
    $total_final_array = array();

    // print_r($quotation['quotation_more_details_array']);
    // die;
    // सम्झौता भयका
    foreach ($amanat['more_detail_count_array'] as $a) {
        array_push($total_more_details_array, $a);
    }
    foreach ($more_detail_count_array as $a) {
        array_push($total_more_details_array, $a);
    }
    foreach ($samiti['samiti_more_details_array'] as $a) {
        array_push($total_more_details_array, $a);
    }
    foreach ($contract['contract_more_details_array'] as $a) {
        array_push($total_more_details_array, $a);
    }
    foreach ($quotation['quotation_more_details_array'] as $a) {
        array_push($total_more_details_array, $a);
    }
    foreach ($ethekka['ethekka_more_details_array'] as $a) {
        array_push($total_more_details_array, $a);
    }
    // पेस्की भुक्तानी लागेका
    foreach ($amanat['advance_count_array'] as $a) {
        array_push($total_advance_array, $a);
    }
    foreach ($advance_count_array as $a) {
        array_push($total_advance_array, $a);
    }
    foreach ($samiti['advance_count_array'] as $a) {
        array_push($total_advance_array, $a);
    }
    foreach ($contract['contract_advance_array'] as $a) {
        array_push($total_advance_array, $a);
    }
    foreach ($quotation['quotation_advance_count_array'] as $a) {
        array_push($total_advance_array, $a);
    }
    foreach ($ethekka['ethekka_advance_count_array'] as $a) {
        array_push($total_advance_array, $a);
    }
    // मुल्यांकन भुक्तानी भयका
    foreach ($amanat['analysis_count_array'] as $b) {
        array_push($total_analysis_array, $b);
    }
    foreach ($analysis_count_array as $b) {
        array_push($total_analysis_array, $b);
    }
    foreach ($samiti['analysis_count_array'] as $b) {
        array_push($total_analysis_array, $b);
    }
    foreach ($contract['contract_analysis_array'] as $b) {
        array_push($total_analysis_array, $b);
    }
    foreach ($quotation['quotation_analysis_count_array'] as $b) {
        array_push($total_analysis_array, $b);
    }
    foreach ($ethekka['ethekka_analysis_count_array'] as $b) {
        array_push($total_analysis_array, $b);
    }
    // अन्तिम भुक्तानी भयका
    foreach ($amanat['final_count_array'] as $f) {
        array_push($total_final_array, $f);
    }
    foreach ($final_count_array as $f) {
        array_push($total_final_array, $f);
    }
    foreach ($samiti['final_count_array'] as $f) {
        array_push($total_final_array, $f);
    }
    foreach ($contract['contract_final_array'] as $f) {
        array_push($total_final_array, $f);
    }
    foreach ($quotation['quotation_final_count_array'] as $f) {
        array_push($total_final_array, $f);
    }
    foreach ($ethekka['ethekka_final_count_array'] as $f) {
        array_push($total_final_array, $f);
    }
    // print_r($total_final_array);
    // die;
    //    echo count($more_detail_count_array);exit;
//    echo "<pre>";print_r($result['samiti_more_details_array']);echo "</pre>";exit;
    $final_result["count"] = count($empty_array);
    $final_result["more_detail_count"] = $total_more_details_count;
    $final_result["advance_count"] = $total_advance_count;
    $final_result["analysis_count"] = $total_analysis_count;
    $final_result["final_count"] = $total_final_count;
    $final_result['count_array'] = $empty_array;
    $final_result['more_detail_count_array'] = $total_more_details_array;
    $final_result['advance_count_array'] = $total_advance_array;
    $final_result['analysis_count_array'] = $total_analysis_array;
    $final_result['final_count_array'] = $total_final_array;
    // print_r($final_result["more_detail_count_array"]);
    // die;
    return $final_result;
}
