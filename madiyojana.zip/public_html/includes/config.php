<?php
	date_default_timezone_set('Asia/Kathmandu');
	defined("DB_SERVER") ? 	NULL : 	define("DB_SERVER", "localhost");
	defined("DB_USER") ? 	NULL : 	define("DB_USER", "bmsnep_bidur_new");
	defined("DB_PASS") ? 	NULL : 	define("DB_PASS", "bidur$$##123");
	defined("DB_NAME") ? 	NULL : 	define("DB_NAME", "bmsnep_bidur_new");
	error_reporting(0);
?>
