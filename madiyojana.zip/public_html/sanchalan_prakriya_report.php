<?php require_once ("includes/initialize.php");
if (!$session->is_logged_in()) {
    redirect_to("logout.php");
}
$mode = getUserMode();
$user = getUser();
error_reporting(-1);
//echo Get_empty_plan();
$type = "";
$ward = "";
$max_ward = Ward::find_max_ward_no();
// print_r($_POST['ward_no']);
?>
<?php include ("menuincludes/header.php"); ?>

<?php
if (isset($_POST['submit'])):
    // ठेक्का मार्फत 
    if (empty($_POST['ward_no'])) {
        $contract_result = Contract_total_investment::find_all();
        $cout0 = count($contract_result);
        $thekka_anu = 0;
        foreach ($contract_result as $contract_result):
            $thekka_anu += $contract_result->agreement_gaupalika;
        endforeach;

        $contract_with = Contractamountwithdrawdetails::find_all();
        $kharcha_rakam = 0;
        foreach ($contract_with as $contract_with):
            $kharcha_rakam += $contract_with->final_total_paid_amount;
        endforeach;

        $baki_thekka = $thekka_anu - $kharcha_rakam;
    } else {
        $contract_result = get_wardwise_result_sql($_POST['ward_no'], "contract_total_investment");
        $cout0 = count($contract_result);
        $thekka_anu = 0;
        foreach ($contract_result as $contract_result):
            $thekka_anu += $contract_result->agreement_gaupalika;
        endforeach;

        $contract_with = Contractamountwithdrawdetails::thekka_total_expenditure_by_ward($_POST['ward_no']);
        $kharcha_rakam = 0;
        foreach ($contract_with as $contract_with):
            $kharcha_rakam += $contract_with->final_total_paid_amount;
        endforeach;

        $baki_thekka = $thekka_anu - $kharcha_rakam;
    }


    //end of thekka //
// e-thekka

    $ethekka = Ethekka_lagat::find_all();
    $e_count = count($ethekka);
    foreach ($ethekka as $e_thekka):
        $ethekka_amount += $e_thekka->agreement_gaupalika;
        $plan_id = $e_thekka->plan_id;
        $ethekka_antim = Planamountwithdrawdetails::ethekka_total_expenditure();
        // print_r("hello");
        // die;
        $banki_ethekka = $ethekka_amount - $ethekka_antim;
    endforeach;
    // ethekka ends here
    // उपभोक्ता मार्फत//
    if (empty($_POST['ward_no'])) {
        $upabhokta_result = Plantotalinvestment::find_all();
        $cout1 = count($upabhokta_result);
        $sanstha_anu = 0;
        $kharcha_rakam_upa = 0;
        foreach ($upabhokta_result as $upabhokta_result_0):
            $gaunpalika_anu += $upabhokta_result_0->agreement_gauplaika;
            $kharcha_rakam_upa = Planamountwithdrawdetails::upabhokta_total_expenditure();
            $baki_upa = $gaunpalika_anu - $kharcha_rakam_upa;
        endforeach;
    } else {
        $upabhokta_result = get_wardwise_result_sql($_POST['ward_no'], "plan_total_investment");
        $cout1 = count($upabhokta_result);
        $sanstha_anu = 0;
        $kharcha_rakam_upa = 0;
        foreach ($upabhokta_result as $upabhokta_result_0):
            $gaunpalika_anu += $upabhokta_result_0->agreement_gauplaika;
            $kharcha_rakam_upa = Planamountwithdrawdetails::upabhokta_total_expenditure_by_ward($_POST['ward_no']);
            // foreach ($kharcha_rakam_upa_one as $kru):
            //     $kharcha_rakam_upa = $kru->final_total_paid_amount;
            // endforeach;
            $baki_upa = $gaunpalika_anu - $kharcha_rakam_upa;
        endforeach;
    }

    // संस्था मार्फत //
    if (empty($_POST['ward_no'])) {
        $sanstha_result = Samitiplantotalinvestment::find_all();
        $cout2 = count($sanstha_result);
        $sanstha_anu = 0;
        $kharcha_rakam_sanstha = 0;
        foreach ($sanstha_result as $sanstha_result_0):
            $sanstha_anu += $sanstha_result_0->agreement_gauplaika;
            $kharcha_rakam_sanstha = Samitiplanamountwithdrawdetails::sanstha_total_expenditure();
            $baki_sanstha = $sanstha_anu - $kharcha_rakam_sanstha;
        endforeach;
    } else {
        $sanstha_result = get_wardwise_result_sql($_POST['ward_no'], "samiti_plan_total_investment");
        $cout2 = count($sanstha_result);
        $sanstha_anu = 0;
        $kharcha_rakam_sanstha = 0;
        foreach ($sanstha_result as $sanstha_result_0):
            $sanstha_anu += $sanstha_result_0->agreement_gauplaika;
            $kharcha_rakam_sanstha = Samitiplanamountwithdrawdetails::sanstha_total_expenditure_by_ward($_POST['ward_no']);
            $baki_sanstha = $sanstha_anu - $kharcha_rakam_sanstha;
        endforeach;
    }

    //end of sanstha //

    // अमानत मार्फत //
    if (empty($_POST['ward_no'])) {
        $amanat_result = AmanatLagat::find_all();
        $cout3 = count($amanat_result);
        $amanat_anu = 0;
        foreach ($amanat_result as $amanat_result):
            $amanat_anu += $amanat_result->agreement_gauplaika;
            $plan_id = $amanat_result->plan_id;
            $new_one = Planamountwithdrawdetails::amanat_total_expenditure();
            $banki_one = $amanat_anu - $new_one;
        endforeach;
    } else {
        $amanat_result = get_wardwise_result_sql($_POST['ward_no'], "amanat_lagat");
        $cout3 = count($amanat_result);
        $amanat_anu = 0;
        foreach ($amanat_result as $amanat_result):
            $amanat_anu += $amanat_result->agreement_gauplaika;
            $plan_id = $amanat_result->plan_id;
            $new_one = Planamountwithdrawdetails::amanat_total_expenditure_by_ward($_POST['ward_no']);
            $banki_one = $amanat_anu - $new_one;
        endforeach;
    }
    // print_r($new_one);
    // end of amanat//

    // कोटेसन मार्फत //
    if (empty($_POST['ward_no'])) {
        $quotation_result = Quotationtotalinvestment::find_all();
        $cout4 = count($quotation_result);
        $kotesan_anu = 0;

        foreach ($quotation_result as $quotation_result_0):
            $kotesan_anu += $quotation_result_0->gaupalika_anudan;
            $plan_id = $quotation_result_0->plan_id;
            $new = Planamountwithdrawdetails::quotation_total_expenditure();
            $banki = $kotesan_anu - $new;
        endforeach;
    } else {
        $quotation_result = get_wardwise_result_sql($_POST['ward_no'], "quotation_total_investment");
        $cout4 = count($quotation_result);
        $kotesan_anu = 0;

        foreach ($quotation_result as $quotation_result_0):
            $kotesan_anu += $quotation_result_0->gaupalika_anudan;
            $plan_id = $quotation_result_0->plan_id;
            $new = Planamountwithdrawdetails::quotation_total_expenditure_by_ward($_POST['ward_no']);
            $banki = $kotesan_anu - $new;
        endforeach;
    }

    //end of kotesan//
    $type = $_POST['type'];
    $ward = $_POST['ward_no'];
endif;
?>
<style>
    .data_ovelwhelm {
        font-weight: bold;
        text-align: center;
    }
</style>
<?php include ("menuincludes/topwrap.php"); ?>
<div id="body_wrap_inner">
    <div class="maincontent">
        <h2 class="headinguserprofile">योजना संचालन प्रकृया रिपोर्ट हेर्नुहोस | <a href="report_dashboard.php"
                class="btn">पछि जानुहोस </a></h2>
        <div class="myMessage">
            <?php echo $message; ?>
        </div>
        <div class="OurContentFull">
            <div class="userprofiletable">
                <form method="post" onsubmit="form.submit()">
                    <div class="inputWrap">
                        <h1>योजना संचालन प्रकृया रिपोर्ट हेर्नुहोस</h1>
                        <div class="titleInput">योजना / कार्यक्रम खोज्नुहोस:</div>
                        <div class="newInput"><select name="type" onchange="form.submit();">
                                <option value="">-छान्नुहोस्-</option>
                                <option value="0" <?php if ($type == 0) {
                                    echo 'selected="selected"';
                                } ?>>योजना</option>
                            </select></div>
                        <div class="titleInput">वार्ड छान्नुहोस् :</div>
                        <?php if ($mode == "user"): ?>
                            <div class="newInput"><select name="ward_no">

                                    <option value="<?= $user->ward ?>">
                                        <?= convertedcit($user->ward) ?>
                                    </option>
                                </select></div>
                        <?php else: ?>
                            <div class="newInput"><select name="ward_no">
                                    <option value="">-छान्नुहोस्-</option>
                                    <?php for ($i = 1; $i <= $max_ward; $i++): ?>
                                        <option value="<?= $i ?>" <?php if ($ward == $i) {
                                              echo 'selected="selected"';
                                          } ?>>
                                            <?= convertedcit($i) ?>
                                        </option>
                                    <?php endfor; ?>
                                </select></div>
                        <?php endif; ?>
                        <div class="saveBtn myWidth100"><input type="submit" class="btn" name="submit"
                                value="खोज्नुहोस" /></div>
                        <div class="myspacer"></div>
                    </div><!-- input wrap ends -->
                </form>
                <?php $nagar_plans = Plandetails1::find_by_sql("select * from plan_details1 where ward_no = 0"); //echo "<pre>";print_r($nagar_plans); ?>
                <?php if (isset($_POST['submit'])):
                    $type = $_POST['type'];
                    ?>
                    <div class="myPrint"><a target="_blank"
                            href="sanchalan_prakriya_print.php?type=<?= $type ?>&ward_no=<?= $ward ?>">प्रिन्ट गर्नुहोस</a>
                    </div>
                    <!-- <div class="myPrint"><a class=""
                            href="report_excel.php?type=<?php echo $type; ?>&ward_no=<?= $ward ?>">Export to EXCEL</a></div> -->
                    <div class="exporte"></div><br>
                    <?php if (!empty($ward)) {
                        echo "<h2>" . convertedcit($ward) . " नं वार्ड को " . get_type_nepali($type) . " हेर्नुहोस </h2>";
                    }
                    ?>
                    <!--<form method="get">-->
                    <table class="table table-bordered table-hover table-striped">
                        <tr>
                            <td class="myCenter"><strong>योजना रिपोर्ट </strong></td>
                            <td class="myCenter"><strong>जम्मा सम्झौता भएका योजनाहरु</strong></td>
                            <td class="myCenter"><strong>जम्मा गाउँपालिका अनुदान </strong></td>
                            <td class="myCenter"><strong>हाल सम्मको खर्च </strong></td>
                            <td class="myCenter"><strong>बाँकी रकम </strong></td>
                            <td class="myCenter"><strong>विवरण हेर्नुहोस </strong></td>
                        </tr>
                        <tr class="data_ovelwhelm">
                            <td class="myCenter">उपभोक्ता समिति मार्फतका योजनाहरु </td>
                            <td class="myCenter"><button class="button btn-secondary" value="">
                                    <?php echo convertedcit($cout1); ?>
                                </button></td>
                            <td class="myCenter">
                                <?php echo convertedcit(placeholder(round($gaunpalika_anu, 2))) ?>/-
                            </td>
                            <td class="myCenter">
                                <?php echo convertedcit(placeholder(round($kharcha_rakam_upa, 2))) ?>/-
                            </td>
                            <td class="myCenter">
                                <?php echo convertedcit(placeholder(round($baki_upa, 2))) ?>/-
                            </td>
                            <td class="myCenter"><a href="upabhokta_samjhauta_report.php?ward_no=<?= $ward ?>"
                                    class="btn">थप
                                    विवरण</a></td>
                        </tr>
                        <tr class="data_ovelwhelm">
                            <td class="myCenter">ठेक्का (Registered Contract) मार्फत सम्झौता भएका योजनाहरु </td>
                            <td class="myCenter"><button class="button btn-secondary" value="">
                                    <?php echo convertedcit($cout0); ?>
                                </button></td>
                            <td class="myCenter">
                                <?php echo convertedcit(placeholder(round($thekka_anu, 2))) ?>/-
                            </td>
                            <td class="myCenter">
                                <?php echo convertedcit(placeholder(round($kharcha_rakam, 2))) ?>/-
                            </td>
                            <td class="myCenter">
                                <?php echo convertedcit(placeholder(round($baki_thekka, 2))) ?>/-
                            </td>
                            <td class="myCenter"><a href="thekka_samjhauta_report.php?ward_no=<?= $ward ?>" class="btn">थप
                                    विवरण</a></td>
                        </tr>
                        <tr class="data_ovelwhelm">
                            <td class="myCenter">ई-ठेक्का (E-bidding Contract) मार्फत सम्झौता भएका योजनाहरु </td>
                            <td class="myCenter"><button class="button btn-secondary" value="">
                                    <?php echo convertedcit($e_count); ?>
                                </button></td>
                            <td class="myCenter">
                                <?php echo convertedcit(placeholder(round($ethekka_amount, 2))) ?>/-
                            </td>
                            <td class="myCenter">
                                <?php echo convertedcit(placeholder(round($ethekka_antim, 2))) ?>/-
                            </td>
                            <td class="myCenter">
                                <?php echo convertedcit(placeholder(round($banki_ethekka, 2))) ?>/-
                            </td>
                            <td class="myCenter"><a href="ethekka_samjhauta_report.php" class="btn">थप विवरण</a></td>
                        </tr>

                        <tr class="data_ovelwhelm">
                            <td class="myCenter">संस्था मार्फत सम्झौता भएका योजनाहरु </td>
                            <td class="myCenter"><button class="button btn-secondary" value="">
                                    <?php echo convertedcit($cout2); ?>
                                </button></td>
                            <td class="myCenter">
                                <?php echo convertedcit(placeholder(round($sanstha_anu, 2))) ?>/-
                            </td>
                            <td class="myCenter">
                                <?php echo convertedcit(placeholder(round($kharcha_rakam_sanstha, 2))) ?>/-
                            </td>
                            <td class="myCenter">
                                <?php echo convertedcit(placeholder(round($baki_sanstha, 2))) ?>/-
                            </td>
                            <td class="myCenter"><a href="sanstha_samjhauta_yojana_report.php?ward_no=<?= $ward ?>"
                                    class="btn">थप विवरण</a></td>
                        </tr>
                        <tr class="data_ovelwhelm">
                            <td class="myCenter">अमानत / हेभी-Equipment मार्फत सम्झौता भएका योजनाहरु </td>
                            <td class="myCenter"><button class="button btn-secondary" value="">
                                    <?php echo convertedcit($cout3); ?>
                                </button></td>
                            <td class="myCenter">
                                <?php echo convertedcit(placeholder(round($amanat_anu, 2))) ?>/-
                            </td>
                            <td class="myCenter">
                                <?php echo convertedcit(placeholder(round($new_one, 2))) ?>/-
                            </td>
                            <td class="myCenter">
                                <?php echo convertedcit(placeholder(round($banki_one, 2))) ?>/-
                            </td>
                            <td class="myCenter"><a href="amanat_samjhauta_yojana_report.php?ward_no=<?= $ward ?>"
                                    class="btn">थप विवरण</a></td>
                        </tr>
                        <tr class="data_ovelwhelm">
                            <td class="myCenter">कोटेशन मार्फत सम्झौता भएका योजनाहरु</td>
                            <td class="myCenter"><button class="button btn-secondary" value="">
                                    <?php echo convertedcit($cout4); ?>
                                </button></td>
                            <td class="myCenter">
                                <?php echo convertedcit(placeholder(round($kotesan_anu, 2))) ?>/-
                            </td>
                            <td class="myCenter">
                                <?php echo convertedcit(placeholder(round($new, 2))) ?>/-
                            </td>
                            <td class="myCenter">
                                <?php echo convertedcit(placeholder(round($banki, 2))) ?>/-
                            </td>
                            <td class="myCenter"><a href="quotation_samjhauta_yojana_list.php?ward_no=<?= $ward ?>"
                                    class="btn">थप विवरण</a></td>
                        </tr>
                        <?php
                        $total_yojana_count = $cout0 + $cout1 + $cout2 + $cout3 + $cout4 + $e_count;
                        $total_anudan = $gaunpalika_anu + $thekka_anu + $sanstha_anu + $amanat_anu + $kotesan_anu + $ethekka_amount;
                        $total_kharcha = $kharcha_rakam_upa + $kharcha_rakam + $kharcha_rakam_sanstha + $new_one + $new + $ethekka_antim;
                        $total_baki = $baki_upa + $baki_thekka + $baki_sanstha + $banki_one + $banki + $banki_ethekka;
                        ?>
                        <tr class="data_ovelwhelm">
                            <td><u>जम्मा विवरण</u></td>
                            <td><button class="button btn-success">
                                    <?= convertedcit($total_yojana_count) ?>
                                </button></td>
                            <td><u>
                                    <?= convertedcit(placeholder(round($total_anudan, 2))); ?>/-
                                </u></td>
                            <td><u>
                                    <?= convertedcit(placeholder(round($total_kharcha, 2))); ?>/-
                                </u></td>
                            <td><u>
                                    <?= convertedcit(placeholder(round($total_baki, 2))); ?>/-
                                </u></td>
                            <td>&nbsp;</td>
                        </tr>
                    </table>
                <?php endif; ?>
                <!--</form>-->
            </div>
        </div>
    </div><!-- main menu ends -->
</div><!-- top wrap ends -->
<?php include ("menuincludes/footer.php"); ?>