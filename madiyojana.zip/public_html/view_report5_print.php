<?php require_once ("includes/initialize.php");
if (!$session->is_logged_in()) {
    redirect_to("logout.php");
}
if ($_GET['ward_no'] == '') {
    $ward_name = " 0 ( पालिका स्तरीय )";
} else {
    $ward_name = convertedcit($_GET['ward_no']);
}
// print_r($_GET['b_id']);
// die;
$counted_result = getOnlyRegisteredPlans($_GET['ward_no']);
if (!empty($_GET['b_id'])) {
    // if (isset($_POST['search'])) {
    if ($_GET['b_id'] != 0) {
        $final_array1 = $counted_result['analysis_count_array'];
        $result = array(); // Initialize an empty array to store results
        $result0 = Plandetails1::find_by_plan_id(implode(",", $final_array1));
        $title = "<div style='color:black;'> तपाई अहिले वडा नं.<u><b>" . $ward_name . "</b></u> को <u><b>" . Topicareaagreement::getName($_GET['b_id']) . "</b></u> मार्फत मुल्यांकनको भुक्तानी भयको योजनाको विवरण हेर्दै हुनुहुन्छ !!! </div>";
        if (!empty($result0)) {
            foreach ($result0 as $r0) {
                $data = Plandetails1::find_by_sql("SELECT * FROM plan_details1 WHERE id=" . $r0->id . " AND topic_area_agreement_id=" . $_GET['b_id']);
                if (!empty($data)) {
                    $result = array_merge($result, $data); // Merge data into result array
                }
            }
        }
    } else {
        $final_array1 = $counted_result['analysis_count_array'];
        $result = Plandetails1::find_by_plan_id(implode(",", $final_array1));
        $title = "<div style='color:black;'>तपाई अहिले वडा नं. <u><b>" . $ward_name . "</b></u> मा मुल्यांकनको भुक्तानी भयको योजनाको विवरण हेर्दै हुनुहुन्छ !!!</div>";
    }
    // }
} else {
    $final_array1 = $counted_result['analysis_count_array'];
    $result = Plandetails1::find_by_plan_id(implode(",", $final_array1));
    $title = "<div style='color:black;'>तपाई अहिले वडा नं. <u><b>" . $ward_name . "</b></u> मा मुल्यांकनको भुक्तानी भयको योजनाको विवरण हेर्दै हुनुहुन्छ !!!</div>";
}
?>
<?php include ("menuincludes/header1.php"); ?>
<!-- js ends -->
</head>
<style>
    body {
        overflow: visible !important;
    }
</style>

<body>
    <div class="myPrintFinal">
        <div class="userprofiletable">
            <div class="printPage">
                <div class="printlogo"><img src="images/emblem_nepal.png" alt="Logo"></div>
                <h1 class="marginright1"><?php echo SITE_LOCATION; ?></h1>
                <h4 class="marginright1"><?php echo SITE_HEADING; ?> </h4>
                <h5 class="marginright1"><?php echo SITE_ADDRESS; ?></h5>
                <div class="myspacer"></div>
                <div class="text-center"><?= $title; ?></div>
                <div class="myspacer"></div>
                <table class="table table-bordered table-hover">
                    <tr>
                        <td>A</td>
                        <td>B</td>
                        <td>C</td>
                        <td>D</td>
                        <td>E</td>
                        <td>F</td>
                        <td>G</td>
                        <td>H</td>
                        <td>I</td>
                        <td>J</td>
                        <td>K</td>
                        <td>L</td>
                        <td>M</td>
                    </tr>
                    <tr>
                        <td class="myCenter"><strong>सि.न </strong></td>
                        <td class="myCenter"><strong>दर्ता नं</strong></td>
                        <td class="myCenter"><strong>योजनाको नाम</strong></td>
                        <td class="myCenter"><strong>योजनाको बिषयगत क्षेत्रको किसिम</strong></td>
                        <td class="myCenter"><strong>योजनाको शिर्षकगत किसिम</strong></td>
                        <td class="myCenter"><strong>मुल्यांकन मिति</strong></td>
                        <td class="myCenter"><strong>योजनाको विनियोजन किसिम</strong></td>
                        <td class="myCenter"><strong>वार्ड नं</strong></td>
                        <td class="myCenter"><strong>अनुदान रु</strong></td>
                        <td class="myCenter"><strong>कुल लागत रु</strong></td>
                        <td class="myCenter"><strong>हाल सम्म लागेको भुक्तानी</strong></td>
                        <td class="myCenter"> <strong>कुल बाँकी रकम</strong></td>
                        <td class="myCenter"> <strong>संचालन प्रक्रिया</strong></td>
                    </tr>
                    <?php $i = 1;
                    $total_net_payable_amount = "";
                    $total_remaining_amount = "";
                    foreach ($result as $data):

                        $samiti_plan_total = Samitiplantotalinvestment::find_by_plan_id($data->id);
                        $contract_plan_total = Contract_total_investment::find_by_plan_id($data->id);
                        $amanat_lagat = AmanatLagat::find_by_plan_id($data->id);
                        $plan_total = Plantotalinvestment::find_by_plan_id($data->id);
                        $quotation_total = Quotationtotalinvestment::find_by_plan_id($data->id);

                        $gender = Costumerassociationdetails::find_by_post_plan_id(1, $data->id);
                        // print_r($gender->mobile_no);
                    
                        $moredetails = Moreplandetails::find_by_plan_id($data->id);
                        $moresamiti = Samitimoreplandetails::find_by_plan_id($data->id);
                        $moreamanat = Amanat_more_details::find_by_plan_id($data->id);
                        $morequotation = Quotationmoredetails::find_by_plan_id($data->id);
                        $contractmore = Contractmoredetails::find_by_plan_id($data->id);
                        $ethekka = Ethekka_lagat::find_by_plan_id($data->id);
                        $contract_info = Contractinfo::find_by_plan_id($data->id);


                        if ($data->type == 1) {
                            $link = "program_total_view.php?id=" . $data->id;
                            $sanchalan_prakiya = '<div style="color:red;">कार्यक्रम मार्फत</div>';
                        } elseif ($data->type == 0 && !empty($samiti_plan_total)) {
                            $link = "view_samiti_plan_form.php?id=" . $data->id;
                            $sanchalan_prakiya = '<div style="color:blue;">संस्था / समिति मार्फत </div>';
                            $kul_lagat = $samiti_plan_total->total_investment;
                            $shramdan = $samiti_plan_total->costumer_investment;
                            $samjhauta_miti = $moresamiti->miti;
                            $contingency = $samiti_plan_total->agreement_gauplaika - $samiti_plan_total->bhuktani_anudan;
                        } elseif ($data->type == 0 && !empty($contract_plan_total)) {
                            $link = "view_all_contract.php?id=" . $data->id;
                            $sanchalan_prakiya = '<div style="color:purple;">ठेक्का मार्फत </div>';
                            $kul_lagat = $contract_plan_total->total_investment;
                            $shramdan = $contract_info->ps;
                            $samjhauta_miti = $contractmore->miti;
                            if ($contract_plan_total->anudan_con == '1') {
                                $contingency = $data->investment_amount * $cont;
                            } else {
                                $contingency = 0;
                            }
                        } elseif ($data->type == 0 && !empty($amanat_lagat)) {
                            $link = "view_all_amanat.php?id=" . $data->id;
                            $sanchalan_prakiya = '<div style="color:orange;">अमानत मार्फत </div>';
                            $kul_lagat = $amanat_lagat->total_investment;
                            $shramdan = $amanat_lagat->costumer_investment;
                            $samjhauta_miti = $moreamanat->miti;
                            // if ($amanat_lagat->anudan_con == '1') {
                            $contingency = $amanat_lagat->agreement_gauplaika - $amanat_lagat->bhuktani_anudan;
                            // } else {
                            //     $contingency = 0;
                            // }
                        } elseif ($data->type == 0 && !empty($morequotation)) {
                            $link = "quotation_setid.php?id=" . $data->id;
                            $sanchalan_prakiya = '<div style="color:magenta;">कोटेसन मार्फत </div>';
                            $kul_lagat = $quotation_total->kul_lagat_anudan;
                            $shramdan = $quotation_total->costumer_investment;
                            $samjhauta_miti = $morequotation->miti;
                            $contingency = $quotation_total->contigency_amount;
                        } elseif ($data->type == 0 && !empty($ethekka)) {
                            $link = "ethekka_set_id.php?id=" . $data->id;
                            $sanchalan_prakiya = '<div style="color:green;">ई-ठेक्का मार्फत </div>';
                            $kul_lagat = $ethekka->contract_total_investment;
                            $shramdan = $ethekka->anya_nikaya_amount;
                            $samjhauta_miti = $ethekka->lagat_miti;
                            $contingency = $ethekka->cont;
                        } else {
                            $link = "view_plan_form.php?id=" . $data->id;
                            $sanchalan_prakiya = "उपभोक्ता मार्फत ";
                            $kul_lagat = $plan_total->total_investment;
                            $shramdan = $plan_total->costumer_investment;
                            $samjhauta_miti = $moredetails->miti;
                            if ($plan_total->anudan_con == '1') {
                                $contingency = $data->investment_amount * $cont;
                            } else {
                                $contingency = 0;
                            }

                        }
                        if (empty($contract_plan_total)) {
                            $mulyankan_payable = Analysisbasedwithdraw::find_by_payment_count(1, $data->id);
                            $net_payable_amount = $mulyankan_payable->total_paid_amount;
                            $remaining_amount = $kul_lagat - $net_payable_amount;
                        } else {
                            $mulyankan_payable = Contractanalysisbasedwithdraw::find_by_payment_count(1, $data->id);
                            $net_payable_amount = $mulyankan_payable->total_paid_amount;
                            $remaining_amount = $kul_lagat - $net_payable_amount;
                        }
                        ?>
                        <tr>
                            <td class="myCenter"><?php echo convertedcit($i); ?></td>
                            <td class="myCenter"><?php echo convertedcit($data->id); ?></td>
                            <td class="myCenter"><?php echo $data->program_name; ?></td>
                            <td class="myCenter"><?php echo Topicarea::getName($data->topic_area_id); ?></td>
                            <td class="myCenter"><?php echo Topicareatype::getName($data->topic_area_type_id); ?></td>
                            <td class="myCenter"><?php echo convertedcit($mulyankan_payable->created_date); ?></td>
                            <td class="myCenter">
                                <?php echo Topicareainvestment::getName($data->topic_area_investment_id); ?>
                            </td>
                            <td class="myCenter"><?php echo convertedcit($data->ward_no); ?></td>
                            <td class="myCenter"><?php echo convertedcit($data->investment_amount); ?></td>
                            <td class="myCenter"><?= convertedcit($kul_lagat); ?></td>
                            <td class="myCenter"><?php echo convertedcit($net_payable_amount); ?></td>
                            <td class="myCenter"><?php echo convertedcit($remaining_amount); ?></td>
                            <td class="myCenter"><?php echo $sanchalan_prakiya; ?></td>
                        </tr>
                        <?php
                        $i++;
                        $total_inv += $data->investment_amount;
                        $tt_lagat += $kul_lagat;
                        $total_net_payable_amount += $net_payable_amount;
                        $total_remaining_amount += $remaining_amount;
                    endforeach;
                    ?>
                    <tr>
                        <td colspan="7">&nbsp; </td>
                        <td>जम्मा </td>
                        <td><b><?php echo convertedcit(placeholder($total_inv)); ?></b></td>
                        <td><b><?php echo convertedcit(placeholder($tt_lagat)); ?></b></td>
                        <td><b><?php echo convertedcit(placeholder($total_net_payable_amount)); ?></b></td>
                        <td colspan="2"><b><?php echo convertedcit(placeholder($total_remaining_amount)); ?></b>
                        </td>
                    </tr>
                </table>


                <div class="myspacer20"></div>
                <div class="oursignature">&nbsp</div>
                <div class="myspacer"></div>

            </div><!-- print page ends -->
        </div><!-- userprofile table ends -->
    </div><!-- my print final ends -->