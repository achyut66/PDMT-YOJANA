<?php require_once ("includes/initialize.php");
if (!$session->is_logged_in()) {
    redirect_to("logout.php");
}
$counted_result = getOnlyRegisteredPlans($_GET['ward_no']);
if ($_GET['ward_no'] == '') {
    $ward_name = " 0 ( पालिका स्तरीय )";
} else {
    $ward_name = convertedcit($_GET['ward_no']);
}
if (!empty($_GET['b_id'])) {
    // if (isset($_POST['search'])) {
    if ($_GET['b_id'] != 0) {
        $final_array1 = $counted_result['final_count_array'];
        $result = array(); // Initialize an empty array to store results
        $result0 = Plandetails1::find_by_plan_id(implode(",", $final_array1));
        $title = "<div style='color:black;'> तपाई अहिले वडा नं.<u><b>" . $ward_name . "</b></u> को <u><b>" . Topicareaagreement::getName($_GET['b_id']) . "</b></u> मार्फत पेस्की भुक्तानी भयको योजनाको विवरण हेर्दै हुनुहुन्छ !!! </div>";
        if (!empty($result0)) {
            foreach ($result0 as $r0) {
                $data = Plandetails1::find_by_sql("SELECT * FROM plan_details1 WHERE id=" . $r0->id . " AND topic_area_agreement_id=" . $_GET['b_id']);
                if (!empty($data)) {
                    $result = array_merge($result, $data); // Merge data into result array
                }
            }
        }
    } else {
        $final_array1 = $counted_result['final_count_array'];
        $result = Plandetails1::find_by_plan_id(implode(",", $final_array1));
        $title = "<div style='color:black;'>तपाई अहिले वडा नं. <u><b>" . $ward_name . "</b></u> मा सम्झौता पेस्की भुक्तानी योजनाको विवरण हेर्दै हुनुहुन्छ !!!</div>";
    }
    // }
} else {
    $final_array1 = $counted_result['final_count_array'];
    $result = Plandetails1::find_by_plan_id(implode(",", $final_array1));
    $title = "<div style='color:black;'>तपाई अहिले वडा नं. <u><b>" . $ward_name . "</b></u> मा सम्झौता पेस्की भुक्तानी योजनाको विवरण हेर्दै हुनुहुन्छ !!!</div>";
}
?>
<?php include ("menuincludes/header1.php"); ?>
<!-- js ends -->
</head>
<style>
    body {
        overflow: visible !important;
    }
</style>

<body>
    <div class="myPrintFinal">
        <div class="userprofiletable">
            <div class="printPage">

                <div class="printlogo"><img src="images/emblem_nepal.png" alt="Logo"></div>
                <h1 class="marginright1">
                    <?php echo SITE_LOCATION; ?>
                </h1>
                <h4 class="marginright1">
                    <?php echo SITE_HEADING; ?>
                </h4>
                <h5 class="marginright1">
                    <?php echo SITE_ADDRESS; ?>
                </h5>
                <div class="myspacer"></div>
                <div class="text-center"><b><?= $title ?></b></div>
                <div class="myspacer"></div>
                <table class="table table-bordered table-hover">
                    <tr>
                        <td>A</td>
                        <td>B</td>
                        <td>C</td>
                        <td>D</td>
                        <td>E</td>
                        <td>F</td>
                        <td>G</td>
                        <td>H</td>
                        <td>I</td>
                        <td>J</td>
                        <td>K</td>
                        <td>L</td>
                        <td>M</td>
                        <td>N</td>
                        <td>O</td>
                        <td>P</td>
                    </tr>
                    <tr>
                        <td class="myCenter"><strong>सि.नं.</strong></td>
                        <td class="myCenter"><strong>दर्ता नं</strong></td>
                        <td class="myCenter"><strong>योजनाको नाम</strong></td>
                        <td class="myCenter"><strong>योजनाको बिषयगत क्षेत्रको किसिम</strong></td>
                        <td class="myCenter"><strong>योजनाको शिर्षकगत किसिम</strong></td>
                        <td class="myCenter"><strong>योजना सम्झौता मिति</strong></td>
                        <td class="myCenter"><strong>वार्ड नं </strong></td>
                        <td class="myCenter"><strong>अध्यक्षको नाम / सम्पर्क नं</strong></td>
                        <td class="myCenter"><strong>अनुदान रु</strong></td>
                        <td class="myCenter"><strong>कुल लागत रकम रु</strong></td>
                        <td class="myCenter"><strong>योजनाको मुल्यांकन रकम रु (Contingency सहित)</strong></td>
                        <td class="myCenter"><strong>हाल सम्म लागेको भुक्तानी (Contingency
                                बाहेक)</strong>
                        </td>
                        <td class="myCenter"><strong>Contingency / Vat रकम (भुक्तानी)</strong></td>
                        <td class="myCenter"><strong>जम्मा भुक्तानी भयको (Contingency
                                सहित)<br>(L+M)</strong></td>
                        <td class="myCenter"><strong>घटी / बढी रकम (I - N)</strong></td>
                        <td class="myCenter"><strong>भुक्तानी भएको मिति </strong></td>
                        <th class="myCenter"><strong>संचालन प्रकिया </strong></th>
                    </tr>
                    <?php $i = 1;
                    $total_net_payable_amount = "";
                    $total_remaining_amount = "";
                    foreach ($result as $data):

                        $samiti_plan_total = Samitiplantotalinvestment::find_by_plan_id($data->id);
                        $contract_plan_total = Contract_total_investment::find_by_plan_id($data->id);
                        $amanat_lagat = AmanatLagat::find_by_plan_id_and_isheavy($data->id, 0);
                        $plan_total = Plantotalinvestment::find_by_plan_id($data->id);
                        $quotation_total = Quotationtotalinvestment::find_by_plan_id($data->id);
                        $is_heavy = AmanatLagat::find_by_plan_id_and_isheavy($data->id, 1);

                        $gender = Costumerassociationdetails::find_by_post_plan_id(1, $data->id);
                        // print_r($gender->mobile_no);
                    
                        $moredetails = Moreplandetails::find_by_plan_id($data->id);
                        $moresamiti = Samitimoreplandetails::find_by_plan_id($data->id);
                        $moreamanat = Amanat_more_details::find_by_plan_id($data->id);
                        $morequotation = Quotationmoredetails::find_by_plan_id($data->id);
                        $contractmore = Contractmoredetails::find_by_plan_id($data->id);
                        $ethekka = Ethekka_lagat::find_by_plan_id($data->id);
                        $contract_info = Contractinfo::find_by_plan_id($data->id);

                        // peski rakam
                        $peski_rakam = Planstartingfund::find_by_plan_id($data->id);
                        $peski_contract = Contractstartingfund::find_by_plan_id($data->id);

                        // check whether the peski rakam is taken from upabhokta or thekka
                        if (!empty($peski_rakam)) {
                            $pesk = $peski_rakam->advance;
                            $remaining = $data->investment_amount - $peski_rakam->advance;
                            $date_advance = $peski_rakam->advance_taken_date;
                        } else {
                            $pesk = $peski_contract->advance;
                            $remaining = $data->investment_amount - $peski_contract->advance;
                            $date_advance = $peski_contract->advance_taken_date;
                        }
                        // antim bhuktani bhayeko yojana
                    
                        $antim_bhuktani = Planamountwithdrawdetails::find_by_plan_id($data->id);
                        $antim_samiti = Samitiplanamountwithdrawdetails::find_by_plan_id($data->id);
                        $contract_bhuktani = Contractamountwithdrawdetails::find_by_plan_id($data->id);

                        // check whether the antim bhuktani is done by which 
                        if (!empty($antim_bhuktani)) {
                            $bhuk_paisa = $antim_bhuktani->final_total_paid_amount;
                            $mulyankan_paisa = $antim_bhuktani->plan_evaluated_amount;
                            $contingency_bhuktani = $antim_bhuktani->final_contengency_amount;
                            $final_net_payable = $bhuk_paisa + $contingency_bhuktani;
                            $bhuktani_miti = $antim_bhuktani->created_date;
                            $ghati_katti = $data->investment_amount - $final_net_payable;
                        } elseif ($contract_bhuktani) {
                            $bhuk_paisa = $contract_bhuktani->final_total_paid_amount;
                            $mulyankan_paisa = $contract_bhuktani->plan_evaluated_amount;
                            $contingency_bhuktani = $contract_bhuktani->vat_amt;
                            $final_net_payable = $contract_bhuktani + $contingency_bhuktani;
                            $bhuktani_miti = $contract_bhuktani->created_date;
                            $ghati_katti = $data->investment_amount - $final_net_payable;
                        } else {
                            $bhuk_paisa = $antim_samiti->final_total_paid_amount;
                            $mulyankan_paisa = $antim_samiti->plan_evaluated_amount;
                            $contingency_bhuktani = $antim_samiti->final_contengency_amount;
                            $final_net_payable = $bhuk_paisa + $contingency_bhuktani;
                            $bhuktani_miti = $antim_samiti->plan_evaluated_date;
                            $ghati_katti = $data->investment_amount - $final_net_payable;
                        }

                        $net_payable_amount = 0;
                        // $remaining_amount = $data->investment_amount;
                        if ($data->type == 1) {
                            $link = "program_total_view.php?id=" . $data->id;
                            $sanchalan_prakiya = '<div style="color:red;">कार्यक्रम मार्फत</div>';
                        } elseif ($data->type == 0 && !empty($samiti_plan_total)) {
                            $link = "view_samiti_plan_form.php?id=" . $data->id;
                            $sanchalan_prakiya = '<div style="color:blue;">संस्था / समिति मार्फत </div>';
                            $kul_lagat = $samiti_plan_total->total_investment;
                            $shramdan = $samiti_plan_total->costumer_investment;
                            $samjhauta_miti = $moresamiti->miti;
                            $contingency = $samiti_plan_total->agreement_gauplaika - $samiti_plan_total->bhuktani_anudan;
                        } elseif ($data->type == 0 && !empty($contract_plan_total)) {
                            $link = "view_all_contract.php?id=" . $data->id;
                            $sanchalan_prakiya = '<div style="color:purple;">ठेक्का मार्फत </div>';
                            $kul_lagat = $contract_plan_total->total_investment;
                            $shramdan = $contract_info->ps;
                            $samjhauta_miti = $contractmore->miti;
                            if ($contract_plan_total->anudan_con == '1') {
                                $contingency = $data->investment_amount * $cont;
                            } else {
                                $contingency = 0;
                            }
                        } elseif ($data->type == 0 && !empty($amanat_lagat)) {
                            $link = "view_all_amanat.php?id=" . $data->id;
                            $sanchalan_prakiya = '<div style="color:orange;">अमानत मार्फत </div>';
                            $kul_lagat = $amanat_lagat->total_investment;
                            $shramdan = $amanat_lagat->costumer_investment;
                            $samjhauta_miti = $moreamanat->yojana_samjhauta_date;
                            // if ($amanat_lagat->anudan_con == '1') {
                            $contingency = $amanat_lagat->agreement_gauplaika - $amanat_lagat->bhuktani_anudan;
                            // } else {
                            //     $contingency = 0;
                            // }
                        } elseif ($data->type == 0 && !empty($is_heavy)) {
                            $link = "view_all_amanat.php?id=" . $data->id;
                            $sanchalan_prakiya = '<div style="color:blue;">हेभी-Equipment मार्फत </div>';
                            $kul_lagat = $amanat_lagat->total_investment;
                            $shramdan = $amanat_lagat->costumer_investment;
                            $samjhauta_miti = $moreamanat->yojana_samjhauta_date;
                            // if ($amanat_lagat->anudan_con == '1') {
                            $contingency = $amanat_lagat->agreement_gauplaika - $amanat_lagat->bhuktani_anudan;
                            // } else {
                            //     $contingency = 0;
                            // }
                        } elseif ($data->type == 0 && !empty($morequotation)) {
                            $link = "quotation_setid.php?id=" . $data->id;
                            $sanchalan_prakiya = '<div style="color:magenta;">कोटेसन मार्फत </div>';
                            $kul_lagat = $quotation_total->kul_lagat_anudan;
                            $shramdan = $quotation_total->costumer_investment;
                            $samjhauta_miti = $morequotation->miti;
                            $contingency = $quotation_total->contigency_amount;
                        } elseif ($data->type == 0 && !empty($ethekka)) {
                            $link = "ethekka_set_id.php?id=" . $data->id;
                            $sanchalan_prakiya = '<div style="color:green;">ई-ठेक्का मार्फत </div>';
                            $kul_lagat = $ethekka->contract_total_investment;
                            $shramdan = $ethekka->anya_nikaya_amount;
                            $samjhauta_miti = $ethekka->lagat_miti;
                            $contingency = $ethekka->cont;
                        } else {
                            $link = "view_plan_form.php?id=" . $data->id;
                            $sanchalan_prakiya = "उपभोक्ता मार्फत ";
                            $kul_lagat = $plan_total->total_investment;
                            $shramdan = $plan_total->costumer_investment;
                            $samjhauta_miti = $moredetails->miti;
                            if ($plan_total->anudan_con == '1') {
                                $contingency = $data->investment_amount * $cont;
                            } else {
                                $contingency = 0;
                            }

                        }
                        ?>
                        <tr>
                            <td class="myCenter">
                                <?php echo convertedcit($i); ?>
                            </td>
                            <td class="myCenter">
                                <?php echo convertedcit($data->id); ?>
                            </td>
                            <td class="myCenter">
                                <?php echo $data->program_name; ?>
                            </td>
                            <td class="myCenter">
                                <?php echo Topicarea::getName($data->topic_area_id); ?>
                            </td>
                            <td class="myCenter">
                                <?php echo Topicareatype::getName($data->topic_area_type_id); ?>
                            </td>
                            <td class="myCenter">
                                <?= convertedcit($samjhauta_miti); ?>
                            </td>
                            <td class="myCenter">
                                <?php echo convertedcit($data->ward_no); ?>
                            </td>
                            <td class="myCenter">
                                <?= $gender->name . ' / ' . convertedcit($gender->mobile_no); ?>
                            </td>
                            <td class="myCenter" style="font-weight:bold;">
                                <?php echo convertedcit($data->investment_amount); ?>
                            </td>
                            <td class="myCenter">
                                <?= convertedcit(round($kul_lagat, 2)); ?>
                            </td>
                            <td class="myCenter">
                                <?= convertedcit(round($mulyankan_paisa, 2)); ?>
                            </td>
                            <td class="myCenter">
                                <?php echo convertedcit(round($bhuk_paisa, 2)); ?>
                            </td>
                            <td class="myCenter"><?= convertedcit(round($contingency_bhuktani, 2)) ?></td>
                            <td class="myCenter" style="font-weight:bold;">
                                <?= convertedcit($final_net_payable) ?>
                            </td>
                            <td class="myCenter">
                                <?php echo convertedcit(round($ghati_katti, 2)); ?>
                            </td>
                            <td class="myCenter">
                                <?php echo convertedcit($bhuktani_miti); ?>
                            </td>
                            <td class="myCenter"><b>
                                    <?php echo $sanchalan_prakiya; ?>
                                </b></td>
                        </tr>
                        <?php $i++;
                        $total_investment += $data->investment_amount;
                        $kul_total += $kul_lagat;
                        $kul_mulyankan += $mulyankan_paisa;
                        $total_net_payable += $bhuk_paisa;
                        $kul_contingency += $contingency_bhuktani;
                        $tt_net_payable += $final_net_payable;
                        $tt_ghati_katti += $ghati_katti;

                        // $total_remaining += $remaining_amount;
                    endforeach; ?>
                    <tr>
                        <td colspan="8"><strong>जम्मा</strong></td>
                        <td>
                            <strong><?php echo convertedcit(placeholder($total_investment)); ?></strong>
                        </td>
                        <td>
                            <strong><?= convertedcit(placeholder($kul_total)); ?></strong>
                        </td>
                        <td><strong><?= convertedcit(placeholder($kul_mulyankan)); ?></strong></td>
                        <td><strong><?= convertedcit(placeholder($total_net_payable)); ?></strong></td>
                        <td><strong><?= convertedcit(placeholder($kul_contingency)); ?></strong></td>
                        <td>
                            <strong><?php echo convertedcit(placeholder($tt_net_payable)); ?></strong>
                        </td>
                        <td><strong><?= convertedcit(placeholder($tt_ghati_katti)); ?></strong></td>
                    </tr>
                </table>


                <div class="myspacer20"></div>
                <div class="oursignature">&nbsp</div>
                <div class="myspacer"></div>

            </div><!-- print page ends -->
        </div><!-- userprofile table ends -->
    </div><!-- my print final ends -->