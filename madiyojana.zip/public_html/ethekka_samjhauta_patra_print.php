<?php require_once("includes/initialize.php");
if (!$session->is_logged_in()) {
  redirect_to("logout.php");
}
if (!isset($_GET['id']) && isset($_SESSION['set_plan_id'])) {
  redirectUrl();
}
$ward_address = WardWiseAddress();
$address = getAddress();
$datas = Costumerassociationdetails::find_by_plan_id($_GET['id']);
//        print_r($datas);exit;
$worker = Moreplandetails::find_by_plan_id($_GET['id']);
$rules_result = Rule::find_by_plan_id($_GET['id']);
$date_selected = $_GET['date_selected'];
$url = get_base_url();
$user = getUser();
$print_history = PrintHistory::find_by_url_and_plan_id($url, $_GET['id']);
if (empty($print_history)) {
  $print_history = new PrintHistory;
}
$print_history->url = get_base_url();
$print_history->nepali_date = $date_selected;
$print_history->english_date = DateNepToEng($date_selected);
$print_history->user_id = $user->id;
$print_history->plan_id = $_GET['id'];
$print_history->save();
?>
<?php $data1 = Plandetails1::find_by_id($_GET['id']); ?>
<?php $data = Plandetails1::find_by_id($_GET['id']);
$fiscal = FiscalYear::find_by_id($data->fiscal_id);
$print_history->worker1 = $_GET['worker1'];
$print_history->worker2 = $_GET['worker2'];
$print_history->worker3 = $_GET['worker3'];
$print_history->worker4 = $_GET['worker4'];
$print_history->save();
if (!empty($_GET['worker1'])) {
  $worker1 = Workerdetails::find_by_id($_GET['worker1']);
} else {
  $worker1 = Workerdetails::setEmptyObject();
}
if (!empty($_GET['worker2'])) {
  $worker2 = Workerdetails::find_by_id($_GET['worker2']);
} else {
  $worker2 = Workerdetails::setEmptyObject();
}
if (!empty($_GET['worker3'])) {
  $worker3 = Workerdetails::find_by_id($_GET['worker3']);
} else {
  $worker3 = Workerdetails::setEmptyObject();
}
if (!empty($_GET['worker4'])) {
  $worker4 = Workerdetails::find_by_id($_GET['worker4']);
} else {
  $worker4 = Workerdetails::setEmptyObject();
}
?>
<?php
$data = Plandetails1::find_by_id($_GET['id']);
$fiscal = FiscalYear::find_by_id($data->fiscal_id);
$invest_details = Ethekka_lagat::find_by_plan_id($_GET['id']);
//    print_r($invest_details);
$datainfo = Ethekkainfo::find_by_plan_id($_GET['id']);
//    print_r($datainfo);
$asay = PrintHistory::find_by_url_and_plan_id('ethekka_aashay_suchana_print.php', $_GET['id']);
$samjhauta = PrintHistory::find_by_url_and_plan_id('ethekka_samjhauta_print.php', $_GET['id']);
?>
<?php include("menuincludes/header1.php"); ?>
<!-- js ends -->
<title>योजना संझौता फाराम print page::
  <?php echo SITE_SUBHEADING; ?>
</title>
<style>
  table {

    width: 100%;
    border: none;
  }

  /* body {
    overflow: visible !important;
  } */
</style>
</head>

<body>
  <div class="myPrintFinal" id="div_new">
    <div class="userprofiletable">
      <div class="printPage">
        <div class="image-wrapper">
          <a href="#"><img src="images/janani.png" align="left" class="scale-image" /></a>
          <div />

          <div class="image-wrapper">
            <a href="#" target="_blank"><img src="images/bhaire.png" align="right" class="scale-image" /></a>
            <div />
            <div style="color:red">
              <h1 class="marginright1.5 letter-title-one">
                <?php echo SITE_LOCATION; ?>
              </h1>
              <h5 class="marginright1.5 letter-title-two">
                <?php echo $address; ?>
              </h5>

              <h5 class="marginright1.5 letter-title-four">
                <?php echo $ward_address; ?>
              </h5>
              <h5 class="marginright1.5 letter-title-three">
                <?php echo SITE_SECONDSUBHEADING; ?>
              </h5>
            </div>
            <div class="myspacer"></div>
            <div class="printContent">
              <div class="mydate">मिति :
                <?php echo convertedcit($date_selected); ?>
              </div>
              <div class="patrano">आर्थिक वर्ष :
                <?php echo convertedcit($fiscal->year); ?>
              </div>
              <div class="patrano"> योजना दर्ता नं :
                <?php echo convertedcit($_GET['id']) ?>
              </div>
              <div class="myspacer"></div>
              <div class="banktextdetails1 ">
                <div class="subject">
                  <u>विषय:-
                    <?php if (!empty($_GET['subject'])) {
                      echo $_GET['subject'];
                    } else {
                      echo "योजना संझौता पत्र ।";
                    } ?>
                  </u>
                </div>
                <div class="myspacer"></div>
                <div class="banktextdetails">
                  लिखितम श्री <strong>
                    <?= SITE_LOCATION . ' ' . SITE_HEADING . ' ' . SITE_DISTRICT ?>
                  </strong> (यस पछी प्रथम पक्ष) र
                  <strong>
                    <?= $datainfo->firm_name . ' ' . $datainfo->firm_address ?>
                  </strong> प्रतिनिधि
                  <strong>
                    <?= $datainfo->firm_owner_name ?>
                  </strong>
                  (यस पछी दोश्रो पक्ष) का बीच मिति <strong>
                    <?= convertedcit($invest_details->yojanaa_samjhauta_date) ?>
                  </strong>
                  गते E-gp मार्फत निर्माण कार्य गराउने सम्बन्धि सुचना अनुसार ठेक्का नं <strong>
                    <?= $datainfo->thekka_no ?>
                  </strong>
                  निर्माण गर्नका लागि रित पूर्वक पेश भएका दरभाउपत्रहरु मध्ये श्री <strong>
                    <?= $datainfo->firm_name ?>
                  </strong>
                  को दररेट आर्थिक तथा प्राविधिक मुल्यांकनबाट सारभूत रुपमा प्रभावग्राही देखिएको <strong>
                    <?= SITE_LOCATION . ' ' . SITE_HEADING ?>
                  </strong>
                  मिति <strong>
                    <?= convertedcit($asay->nepali_date) ?>
                  </strong> को आशयको सुचना तथा यस कार्यालयबाट मिति
                  <strong>
                    <?= convertedcit($samjhauta->nepali_date) ?>
                  </strong>
                  गतेको सम्झौता गर्न आउने सम्बन्धि पत्र बमोजिम दोश्रो पक्षले प्रथम पक्षलाई BOQ
                  मा तोकिएबमोजिमको दररेट र परिमाणमा सेवा उपलब्ध गराउने र प्रथम पक्षले दोश्रो पक्षलाई कबोल बमोजिमको रकम
                  भुक्तानी
                  गर्न गराउन
                  र सो अनुसारको काम नगरेमा प्रचलित कानुन बमोजिम साहुँला बुझाउला भनि राजिखुशी भइ तपसिलमा सर्तनामा कागज
                  लेखि लेखाई
                  सहिछाप
                  गरि <strong>
                    <?= SITE_LOCATION . ' ' . SITE_HEADING ?>
                  </strong> मा चढाएका छौ ।
                </div>
                <div class="myspacer"></div>
                <div class="" style="margin-left:15px; margin-top: 10px; ">
                  <h4><u>इलेकट्रोनिक विडिंग (E-Bidding) बाट योजना सम्झौता गर्दा पालना गरिने शर्तहरु:</u></h4>
                  <div class="myspacer"></div>
                  १). यस कार्यालयको मिति <strong>
                    <?= convertedcit($datainfo->bolpatra_miti) ?>
                  </strong> सुचना अनुसार ठेक्का नं
                  <strong>
                    <?= $datainfo->thekka_no ?>
                  </strong> सिलबन्धि दरभाउपत्र सम्बन्धि सर्तहरु तथा सार्वजनिक खरिद ऐन २०६३ संसोधन
                  समेत र नियमावली २०६४ बमोजिम सकार गर्नुपर्ने छ ।</li>
                  <br><span>
                    २). उपरोक्त कार्य मिति <strong>
                      <?= convertedcit($invest_details->yojana_end_date) ?>
                    </strong> गतेभित्र निर्माण
                    सम्पन्न गरि हस्तान्तरण गर्नुपर्नेछ ।</li>
                    <br>३). सडक निर्माण कार्य पूर्वाधार विकास शाखाको इन्जीनियर वा निजले तोकेको साइट इन्चार्जको रेखदेखमा
                    कार्यलयको
                    लागत इस्टिमेट स्पेसीफिकेसन र डिजाइन बमोजिम गर्नुपर्ने छ ।</li>
                    <br>४). <strong>
                      <?= $data->program_name ?>
                    </strong> कार्यको ल.ई रु.
                    <strong>
                      <?= convertedcit($datainfo->thekka_rakam) ?>
                    </strong> भएकोमा कबोल अंक रु.
                    <strong>
                      <?= convertedcit($datainfo->kabol_rakam) ?>
                    </strong> (मूल्य अभिवृद्धि कर र पीयस आइटम सहित) प्रथम पक्षले
                    दोश्रो पक्षलाई उपलब्ध गराउनेछ ।</li>
                    <br>५). निर्माण कार्य संचालन गर्दा कुनै दुबिधा भएमा दुवै पक्षको आपसी सहमतिमा समाधान गरिनेछ ।</li>
                    <br>६). निर्माण कार्य सम्पन्न भएपछी प्राबिधिक मुल्यांकन बाट अन्तिम बिल प्राप्त नभए भुक्तानी दिइने
                    छैन ।</li>
                    <br>७). सम्झौतामा उल्लेख नभयका अन्य कुराहरु बिड डकुमेन्टमा उल्लेख भए बमोजिम हुनेछ ।</li>
                    <?php if (!empty($rules_result)):
                      foreach ($rules_result as $data): ?>
                        <li>
                          <?= $data->rule ?>
                        </li>
                      <?php endforeach; endif; ?>

                </div>
                <div class="myspacer"></div>
                <div class="text-center"><i>माथि उल्लेख भए बमोजिमका शर्तहरु पालना गर्न हामी निम्न पक्षहरु मन्जुर गर्दछौं
                    ।</i></div>
                <!-- <div class="myspacer"></div> -->
                <div class="myspacer"></div>
                <div class="mycontent">
                  <table>
                    <tr>
                      <td class="myWidth25 myCenter"><strong>दोश्रो पक्ष : ठेकेदारको तर्फबाट</strong></td>
                      <td class="myWidth25 myCenter"><strong>प्रथम पक्ष : कार्यालयको तर्फबाट</strong></td>
                    </tr>
                    <tr>
                      <td class="myHeight20"><b>दस्तखत:</b></td>
                      <td class="myHeight20"><b>दस्तखत:</b></td>
                    </tr>
                    <tr>
                      <td>नाम थर:
                        <?= $datainfo->firm_owner_name ?>
                      </td>
                      <td><b>नाम / पद: </b>
                        <?php echo $worker1->authority_name . ' / ' . $worker1->post_name; ?>
                      </td>
                    </tr>
                    <tr>
                      <td>फर्मको नाम:
                        <?= $datainfo->firm_name ?>
                      </td>
                      <td>ठेगाना:
                        <?php echo SITE_LOCATION; ?>-
                        <?php echo SITE_HEADING; ?>
                      </td>
                    </tr>
                    <tr>
                      <td colspan="2" class="text-center">मिति:
                        <?php echo convertedcit($invest_details->yojanaa_samjhauta_date); ?>
                      </td>
                    </tr>
                  </table>
                  <div class="myspacer"></div>
                  <table>
                    <tr>
                      <td colspan="2" class="myCenter"><strong>रोहबर</strong></td>
                    </tr>
                    <tr>
                      <td>नाम र पद :
                        <?= $worker2->authority_name . ' / ' . $worker2->post_name ?>
                      </td>
                      <td>नाम र पद :
                        <?= $worker3->authority_name . ' / ' . $worker3->post_name ?>
                      </td>
                    </tr>
                  </table>
                </div><!-- sthaaniy taha ends -->
              </div><!-- bank details ends -->
              <div class="myspacer"></div>
            </div>
          </div><!-- print page ends -->
        </div><!-- userprofile table ends -->
      </div><!-- my print final ends -->