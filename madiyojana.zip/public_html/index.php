<?php
require_once("includes/initialize.php");
if(!$session->is_logged_in()){ redirect_to("logout.php");}
$mode=getUserMode();
$user = getUser();
// pp($user);
//error_reporting(1);
$url =  "{$_SERVER['HTTP_HOST']}{$_SERVER['REQUEST_URI']}";
$base_url1 = Explode("/", $url);
array_pop($base_url1);
$base_url ="http://".implode("/",$base_url1)."/";
// print_R($base_url);die;

$json1 = @file_get_contents($base_url . "get_yojana_report.php");
// print_r($json1);die;
if ($json1 !== false) {
    $yojana_data = json_decode($json1, true);
    $yojana_array =array();
    $count_array = array();
    $anudan_array = array();
    $kharcha_array = array();
    $baki_array = array();
    foreach ($yojana_data as $key => $value) {
        array_push($yojana_array,$value['yojana']);
        array_push($count_array, $value['count']);
        array_push($anudan_array,$value['anudan']);
        array_push($kharcha_array,$value['kharcha']);
        array_push($baki_array,$value['baki']);
    }
} else {
    // Handle error fetching JSON data
    // echo "";
}
// print_r($yojana_data);die;
// $yojana_data = json_decode($json1, true);
// print_r($yojana_data);
$json2 = @file_get_contents($base_url . "get_karyakam_report.php");
if ($json2 !== false) {
    $yojana_data1 = json_decode($json2, true);
    $yojana_array1 =array();
    $count_array1 = array();
    $anudan_array1 = array();
    $kharcha_array1 = array();
    $baki_array1 = array();
    
    foreach ($yojana_data1 as $key => $value) {
        array_push($yojana_array1,$value['yojana']);
        array_push($count_array1, $value['count']);
        array_push($anudan_array1,$value['anudan']);
        array_push($kharcha_array1,$value['kharcha']);
        array_push($baki_array1,$value['baki']);
    }

} else {
    // Handle error fetching JSON data
    // echo "";
}
$json3 = @file_get_contents($base_url . "get_yojana_bikash_report.php");
if ($json3 !== false) {
    $yojana_data2 = json_decode($json3, true);
    $topic_array =array();
    $count_array2 = array();
    foreach ($yojana_data2 as $key => $value) {
        array_push($topic_array,$value['topic']);
        array_push($count_array2, $value['count']);
    }
} else {
    // Handle error fetching JSON data
    // echo "";
}
$counted_result = getOnlyRegisteredPlans($_GET['ward_no']);
$samjhauta_array=$counted_result['more_detail_count_array'];
$miti = generateCurrDate();
$mode= getUserMode();
?>
<button class="button btn-secondary" style="width: 100%;margin-top:0%">
<marquee onmouseover="this.stop()" onmouseout="this.start()">
    <a href="https://www.mofaga.gov.np/" style="color: white;" target="_blank"><img src="images/janani.png" height="20" width="20"> संघीय / परराष्ट्र मन्त्रालय</a><span>
    </span> || <a href="https://www.onlinekhabar.com/" style="color: white;margin-left:50px;" target="_blank"><img src="images/onlinekhabar.png" height="20" width="25"> अनलाइन खबर डट कम</a><span>
    </span> || <a href="https://www.ratopati.com/" style="color: white;margin-left:50px;" target="_blank"><img src="images/ratopati1.png" height="20" width="30"> रातोपार्टी डट कम</a><span>
    </span> || <a href="https://www.moic.gov.np/" style="color: white;margin-left:50px;" target="_blank"><img src="images/janani.png" height="20" width="20"> सूचना तथा सञ्चार मन्त्रालय</a><span>
    </span> || <a href="https://www.google.com/" style="color: white;margin-left:50px;" target="_blank"><img src="images/google.png" height="20" width="20"> Google.com</a><span>
    </span> || <a href="https://www.youtube.com/" style="color:white;margin-left:50px;" target="_blank"><img src="images/youtube.png" height="20" width="20"> YouTube</a><span>
    </span> || <a href="https://merotalim.com/preeti-unicode" style="color:white;margin-left:50px;" target="_blank"><img src="images/converter.png" height="20" width="20"> Preeti To Unicode Converter</a><span>
</marquee>
</button>
  <!-- ======= Header ======= -->
  <?php include("menuincludes/header.php");?>
<div class="header">
<?php include("menuincludes/topwrap.php");?>
</div>
  <!-- End Header -->
  <!-- ======= Hero Section ======= -->
  <!-- <section id="hero" class="d-flex justify-cntent-center align-items-center"> -->
 <!-- </section> -->
  <!-- End Hero -->
<div class="myspacer30"></div>
<button class="button btn-warning text-center" style="width: 100%;">ग्राफिकल रिपोर्ट</button>
            <div class="my_chart_box">
                <div class="chart-container">
                    <canvas id="yojana_report"> </canvas>
                </div>
                <div id="yojana_detail" class="chart_detail" style="display: none">
                    <table class="chart_index borderless">
                        <?php $i=0;
                                foreach($yojana_array as $data){?>
                        <tr>
                            <td>
                                <div class="yojana_<?=$i?>"></div>
                                <?=$data?>&nbsp;(
                                <?=convertedcit($count_array[$i])?>)
                                <hr>
                            </td>
                        </tr>
                        <?php $i++;}?>

                    </table>
                </div>
                <div class="chart_clear"></div>
            </div>
            <div class="my_chart_box">
                <div class="chart-container">
                    <canvas id="yojana_report1"> </canvas>
                </div>
                <div id="yojana_detail1" class="chart_detail" style="display: none">
                    <table class="chart_index borderless">
                        <?php $i=0;
                                        foreach($yojana_array1 as $data){ 
                                            if(empty($count_array1[$i]))
                                            {
                                                $count = 0;
                                            }
                                            else
                                            {
                                                $count =$count_array1[$i];
                                            }
                                        ?>
                        <tr>
                            <td>
                                <div class="yojana1_<?=$i?>"></div>
                                <?=$data?>&nbsp;(
                                <?=convertedcit($count)?>)
                                <hr>
                            </td>
                        </tr>
                        <?php $i++;}?>

                    </table>
                </div>
                <div class="chart_clear"></div>
            </div>
            <div class="my_chart_box">
                <div class="chart-container">
                    <canvas id="yojana_report2"> </canvas>
                </div>
                <div id="yojana_detail2" class="chart_detail" style="display: none">
                    <table class="chart_index borderless">
                        <tr>
                            <td>
                                <div class="yojana2_1"> </div>जम्मा खर्च
                            </td>
                        </tr>
                        <tr>
                        <td>
                            <div class="yojana2_2"> </div>हाल सम्मको खर्च
                        </td>
                        </tr>
                        <tr>
                        <td>
                            <div class="yojana2_3"> </div>बाकी रकम
                        </td>

                        </tr>

                    </table>
                </div>
                <div class="chart_clear"></div>
            </div>
            <div class="my_chart_box">
                <div class="chart-container">
                    <canvas id="yojana_report3"> </canvas>
                </div>
                <div id="yojana_detail3" class="chart_detail" style="display: none; margin-top: -40px;">
                    <table class="chart_index borderless">

                        <?php $i=0;
                                    foreach($topic_array as $data){ 
                                    ?>
                        <tr>

                            <td>
                                <div class="yojana3_<?=$i?>"></div>
                                <?=$data?>&nbsp;(
                                <?=convertedcit($count_array2[$i])?>)
                                <hr>
                            </td>

                        </tr>
                        <?php $i++;}?>

                    </table>
                </div>
                <div class="chart_clear"></div>
            </div>
<div class="chart_clear"></div>
</body>
<!-- Messenger Chat Plugin Code -->
    <div id="fb-root"></div>

    <!-- Your Chat Plugin code -->
    <div id="fb-customer-chat" class="fb-customerchat">
    </div>

    <script>
      var chatbox = document.getElementById('fb-customer-chat');
      chatbox.setAttribute("page_id", "101230232645265");
      chatbox.setAttribute("attribution", "biz_inbox");
    </script>

    <!-- Your SDK code -->
    <!-- <script>
      window.fbAsyncInit = function() {
        FB.init({
          xfbml            : true,
          version          : 'v14.0'
        });
      };

      (function(d, s, id) {
        var js, fjs = d.getElementsByTagName(s)[0];
        if (d.getElementById(id)) return;
        js = d.createElement(s); js.id = id;
        js.src = 'https://connect.facebook.net/en_US/sdk/xfbml.customerchat.js';
        fjs.parentNode.insertBefore(js, fjs);
      }(document, 'script', 'facebook-jssdk'));
    </script> -->
    
</table>
<button class="button btn-warning text-center" style="width: 100%;">म्याद थप गर्नुपर्ने सम्झौता भएका योजनाहरु</button>
<!-- <div id = "tala" style="margin-top: -15px;"> -->
 <div class="card-body">
 <div class="table-responsive">
                <table class="table table-dark">
                    <thead>
                        <tr>
                            <th>सी.नं.</th>
                            <th>योजनाको नाम</th>
                            <th>दर्ता नं</th>
                            <th>योजना शुरू हुने मिति</th>
                            <th>योजना सकिने मिति</th>
                            <th>योजना सम्झौता मिति</th>
                            <th>उपभोक्ता समितिको (अध्यक्षको नाम)</th>
                            <th>मोबाइल नं</th>
                            <th>सम्झौता अनुसारको मिति सकिन बाकी दिन</th>
                        </tr>
                        </thead>
                        <tbody>
                             
                            <?php 
                            $i = 1; foreach($result as $key=> $data):
                            // print_r($datas);
                            $samjhauta_plan = Moreplandetails::find_by_plan_id($data->id);
                            $name = Costumerassociationdetails::find_by_plan_id_post_id($data->id,1);
                            //$date1 = $samjhauta_plan->yojana_sakine_date;
                            $miti_days = Moreplandetails::find_by_plan_id($data->id);//print_r($miti_days);
                            //print_r($miti_days);
                            $date1 = $miti_days->yojana_sakine_date;
                             ?>
                             <?php
                                $datetime1 = new DateTime("$date1");

                                $datetime2 = new DateTime("$miti");
                                
                                $difference = $datetime1->diff($datetime2);
                            ?>
                        <tr>
                            <td><?php echo convertedcit($i);?></td>
                            <td><?php echo $data->program_name;?></td>
                            <td><button type="button" class="darta_id btn-info" ><?php echo convertedcit($data->id);?></button></td>
                            <td><?php echo convertedcit($samjhauta_plan->yojana_start_date);?></td>
                            <td><?php echo convertedcit($samjhauta_plan->yojana_sakine_date);?></td>
                            <td><?php echo convertedcit($samjhauta_plan->miti);?></td>
                            <td><?php echo $name->name;?></td>
                            
                            <td>
                                <input type = "hidden" name="mobile" value = "<?php echo $name->mobile_no?>" id="mobile">
                                <input type = "hidden" name="mobile" value = "<?php echo $data->program_name?>" id="prgrm_name">
                                <input type = "hidden" name="mobile" value = "<?php echo convertedcit($samjhauta_plan->miti)?>" id="miti">
                                <input type = "hidden" name="name" value = "<?php echo $name->name?>" id= "name">
                                
                                <button type="btn" class="mobile btn-info" value="<?php echo convertedcit($name->mobile_no);?>" id="<?php echo $name->mobile_no?>"><?php echo convertedcit($name->mobile_no);?></button></td>
                                <td>
                                <?php if($datetime1 <= $datetime2){ ?>
                                <button class="button btn-secondary" style='background-color:red;'><?php echo convertedcit($difference->days); echo "<div>दिन सकिएको</div>"; ?></button>
                                    
                                <?php }else{ ?>
                                <button class="button btn-secondary" style='background-color:green;'><?php echo convertedcit($difference->days); echo "<div>दिन बाँकी</div>"; ?></button>
                                    
                                <?php }?>
                                    <input type = "hidden" name="mobile" value = "<?php echo convertedcit($difference->days)?>" id="diff">
                            </td>
                        </tr>
                        </tbody>
                         <?php  $i++;endforeach;?>
                    </table>
                  </div>
  </div>
<?php include("menuincludes/footer.php");?>
<script src="js/graphical.js"></script>