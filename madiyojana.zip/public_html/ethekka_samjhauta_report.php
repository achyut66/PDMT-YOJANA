<?php require_once ("includes/initialize.php");
if (!$session->is_logged_in()) {
    redirect_to("logout.php");
}
$mode = getUserMode();
$counted_result = getOnlyRegisteredPlans($_GET['ward_no']);
if ($mode != "administrator" && $mode != "superadmin") {
    die("ACCESS DENIED");
}

$ethekka_result = Ethekka_lagat::find_all();
$plan_array = array();
foreach ($ethekka_result as $data1) {
    array_push($plan_array, $data1->plan_id);
}
$count0 = count($plan_array);
$result = Plandetails1::find_by_plan_id(implode(",", $plan_array));
// on form submit check the value of each yojana karyakram
// print_r($result);

$final_array = $counted_result['final_count_array'];
?>
<?php include ("menuincludes/header.php"); ?>
<title>
    <?php echo "इ-ठेक्का सम्झौता योजनाहरु !!!"; ?>
</title>

<body>
    <?php include ("menuincludes/topwrap.php"); ?>
    <div id="body_wrap_inner">
        <div class="maincontent">
            <h2 class="headinguserprofile">इ-ठेक्का मार्फत सम्झौता भएका योजनाहरु | <a href="report.php" class="btn">पछि
                    जानुहोस</a> |<a target="_blank" href="ethekka_samjhauta_report_print.php" class="btn">Print</a>
            </h2>
            <!-- <div class="inputWrap50">
            <div class="card">
                <form method="post" enctype="multipart/form-data">
                <div class="card-header text-center">योजनाको उप-शिर्षकगत किसिम छानुहोस</div>
                <div class="card-body">
                    <div class="titleInput">उपशीर्षक</div>
                    <div class="newInput">
                        <select name="up_shirshak">
                            <option value="0">---छानुहोस---</option>
                            <option value="1">यातायात पूर्वाधार / सडक</option>
                            <option value="2">सिंचाई</option>
                            <option value="3">खानेपानी</option>
                            <option value="4">खेलकुद</option>
                            <option value="5">भवन</option>
                            <option value="6">अन्य</option>
                        </select>
                    </div>
                    <div class="text-right"><button class="button btn-success" type="submit" name="submit" style="border-radius:10px;">खोज्नुहोस</button></div>
                </div>
                </form>
            </div>
            </div> -->

            <div class="myMessage"><?php echo $message; ?></div>
            <div class="OurContentFull">

                <!--<h2>बिषयगत क्षेत्रको नाम </h2>-->
                <div class="userprofiletable">
                    <div class="myPrint"></div><br>
                    <table class="table table-bordered table-responsive table-striped" width="100%">
                        <tr>
                            <td class="myCenter"><strong>सि.न </strong></td>
                            <td class="myCenter"><strong>दर्ता नं</strong></td>
                            <td class="myCenter"><strong>राजपत्र नं</strong></td>
                            <td class="myCenter"><strong>योजनाको नाम</strong></td>
                            <td class="myCenter"><strong>वार्ड नं </strong></td>
                            <td class="myCenter"><strong>विनियोजित रु </strong></td>
                            <td class="myCenter"><strong>ईष्टिमेट रकम</strong></td>
                            <td class="myCenter"><strong>सम्झौता मिति </strong></td>
                            <!-- <td class="myCenter"><strong>मुल्यांकन रकम</strong></td> -->
                            <td class="myCenter"><strong>अन्तिम भुक्तानी रकम</strong></td>
                            <td class="myCenter"><strong>कार्यसम्पन्न मिति</strong></td>
                            <td class="myCenter"><strong>पेस्की भुक्तानी रकम</strong></td>
                            <td class="myCenter"><strong>पेस्की मिति</strong></td>
                            <td class="myCenter"><strong>मुल्यांकन भुक्तानी रकम</strong></td>
                            <td class="myCenter"><strong>मुल्यांकन मिति</strong></td>
                            <td class="myCenter"><strong>संचालन प्रक्रिया</strong></td>
                            <td class="myCenter"><strong>दोस्रो पक्ष( फर्मको नाम ) / सम्पर्क नं</strong>
                            </td>
                            <td class="myCenter"><strong>कैफियत</strong></td>
                        </tr>
                        <?php $i = 1;
                        foreach ($result as $re):
                            $samjhauta_bibaran = Ethekkainfo::find_by_plan_id($re->id);
                            $antim_bhuktani = Planamountwithdrawdetails::find_by_plan_id($re->id);
                            $mulyankan_bhuktani = Analysisbasedwithdraw::find_by_plan_id($re->id);
                            $ethekka_advance = Planstartingfund::find_by_plan_id($re->id);
                            $mulyankan_bhuktani = $mulyankan_bhuktani[0];
                            // print_r($mulyankan_bhuktani);
                        
                            if (!empty($mulyankan_bhuktani)) {
                                $total_plan_evaluated = $mulyankan_bhuktani->evaluated_amount;
                                $mulyankan_bhuk_rakam = $mulyankan_bhuktani->total_paid_amount;
                                $final_paid_amount = 0;
                                $advance_rs = 0;
                                $mulyankan_bhuk_miti = $mulyankan_bhuktani->created_date;
                                $antim_bhuktani_miti = '-';
                                $peski_miti = '-';
                                $miti = '-';
                                $sanchalan_prakriya = '<div style="color:blue;font-weight:bold;"> मुल्यांकन अनुसार भुक्तानी भएको </div>';
                            } elseif (!empty($antim_bhuktani)) {
                                $total_plan_evaluated = $antim_bhuktani->plan_evaluated_amount;
                                $mulyankan_bhuk_rakam = 0;
                                $final_paid_amount = $antim_bhuktani->final_total_paid_amount;
                                $advance_rs = 0;
                                $mulyankan_bhuk_miti = '-';
                                $antim_bhuktani_miti = $antim_bhuktani->plan_end_date;
                                $peski_miti = '-';
                                $miti = $antim_bhuktani->plan_end_date;
                                $sanchalan_prakriya = '<div style="color:green;font-weight:bold;">अन्तिम भुक्तानी भएको</div>';
                            } elseif (!empty($ethekka_advance)) {
                                $total_plan_evaluated = 0;
                                $mulyankan_bhuk_rakam = 0;
                                $final_paid_amount = 0;
                                $advance_rs = $ethekka_advance->advance;
                                $mulyankan_bhuk_miti = '-';
                                $antim_bhuktani_miti = '-';
                                $peski_miti = $ethekka_advance->advance_taken_date;
                                $miti = '-';
                                $sanchalan_prakriya = '<div style="color:green;font-weight:bold;">पेस्की भुक्तानी लागेको</div>';
                            } else {
                                $total_plan_evaluated = 0;
                                $mulyankan_bhuk_rakam = 0;
                                $final_paid_amount = 0;
                                $advance_rs = 0;
                                $mulyankan_bhuk_miti = '-';
                                $antim_bhuktani_miti = '-';
                                $peski_miti = '-';
                                $miti = '-';
                                $sanchalan_prakriya = '<div style="color:red;font-weight:bold;">' . 'सम्झौता मात्र भयको' . '</div>';
                            }
                            // $all_bhuktani = $total
                            ?>
                            <tr>
                                <td class="myCenter"><?php echo convertedcit($i); ?></td>
                                <td class="myCenter"><?php echo convertedcit($re->id); ?></td>
                                <td class="myCenter"><?= convertedcit($re->rajpatra_no) ?></td>
                                <td class="myCenter"><?php echo $re->program_name; ?></td>
                                <!--<td class="myCenter"><?php echo Topicareainvestment::getName($re->topic_area_investment_id); ?></td>-->
                                <td class="myCenter"><?php echo convertedcit($re->ward_no); ?></td>
                                <td class="myCenter"><?= convertedcit(placeholder($re->investment_amount)); ?>/-</td>
                                <td class="myCenter">
                                    <?= convertedcit(placeholder(round($samjhauta_bibaran->kabol_rakam, 2))); ?>/-
                                </td>
                                <td class="myCenter"><?= convertedcit($samjhauta_bibaran->print_date); ?></td>
                                <td class="myCenter"><?= convertedcit(placeholder($final_paid_amount)) ?></td>
                                <td class="myCenter"><?= convertedcit($miti); ?></td>
                                <td class="myCenter"><?= convertedcit(placeholder($advance_rs)) ?></td>
                                <td class="myCenter"><?= convertedcit($peski_miti) ?></td>
                                <td class="myCenter"><?= convertedcit($mulyankan_bhuk_rakam) ?></td>
                                <td class="myCenter"><?= convertedcit($mulyankan_bhuk_miti); ?></td>
                                <td class="myCenter"><?= $sanchalan_prakriya; ?></td>
                                <td class="myCenter">
                                    <?= $samjhauta_bibaran->firm_name . ' / ' . convertedcit($samjhauta_bibaran->contact_no) ?>
                                </td>
                                <td class="myCenter"></td>
                            </tr>
                            <?php
                            $peski += $advance_rs;
                            $total_bhuktani += $final_paid_amount;
                            $estimated += $samjhauta_bibaran->kabol_rakam;
                            $jamma_anudan += $re->investment_amount;
                            $mulyankan_rakam_tot += $mulyankan_bhuk_rakam;
                            $i++;
                        endforeach; ?>
                        <tr>

                            <td colspan="5" style="text-right">जम्मा </td>
                            <td><strong><u><?= convertedcit(placeholder($jamma_anudan)) ?>/-</u></strong></td>
                            <td><strong><u><?= convertedcit(placeholder(round($estimated, 2))); ?>/-</u></strong></td>
                            <td>&nbsp;</td>
                            <td><strong><u><?= convertedcit(placeholder($total_bhuktani)); ?></u></strong></td>
                            <td>&nbsp;</td>
                            <td><strong><u><?= convertedcit(placeholder($peski)); ?></u></strong></td>
                            <td>&nbsp;</td>
                            <td><strong><u><?php echo convertedcit(placeholder($mulyankan_rakam_tot)); ?></u></strong>
                            </td>
                            <td colspan="4">&nbsp;</td>
                        </tr>
                    </table>

                </div>
            </div>
        </div><!-- main menu ends -->

    </div><!-- top wrap ends -->
    <?php include ("menuincludes/footer.php"); ?>