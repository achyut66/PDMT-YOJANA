<?php
require_once ("includes/initialize.php");
if (!$session->is_logged_in()) {
    redirect_to("logout.php");
}
$mode = getUserMode();
$user = getUser();
error_reporting(-1);
//echo Get_empty_plan();
$ward = "";
// include("menuincludes/header.php");
// कोटेसन मार्फत ssamjhauta bhayekaa yojana haruko lists //
$quotation_result = Quotationtotalinvestment::find_all();
//end of kotesan//
$type = $_POST['type'];
$ward = $_POST['ward_no'];
?>

<body>
    <div class="myPrintFinal">
        <div class="userprofiletable">
            <div class="printPage">
                <div class="image-wrapper"><a href="#"><img src="images/janani.png" align="left"
                            class="scale-image" /></a>
                    <div />
                    <div class="image-wrapper"><a href="#" target="_blank"><img src="images/bhaire.png" align="right"
                                class="scale-image" /></a>
                        <div />
                        <div style="color:red;margin-left:400px;" class="text-center;">
                            <h1 style="margin-left:64px;"><?php echo SITE_LOCATION; ?></h1>
                            <h5 style="margin-left:100px;">नगर कार्यपालिकाको कार्यालय</h5>

                            <h5 style="margin-left:130px;">बसन्तपुर,माढी</h5>
                            <h5 style="margin-left:120px;"><?php echo SITE_SECONDSUBHEADING; ?></h5>
                            <h3 style="margin-left:2px;">आ.व. २०८०/२०८१ कोटेसन आयोजना तथा कार्यक्रमको सम्झौता विवरण
                            </h3>
                        </div>
                        <div class="myspacer"></div>
                        <hr />
                        <table class="table table-bordered">
                            <tr>
                                <th>क्र.सं.</th>
                                <th>दर्ता नं</th>
                                <th>योजना तथा कार्यक्रमहरुको नाम</th>
                                <th>विनियोजनको किसिम</th>
                                <th>वडा नं.</th>
                                <th>विनियोजित रकम</th>
                                <th>ईष्टिमेटेट रकम</th>
                                <th>मुल्यांकन रकम</th>
                                <th>भुक्तानी रकम</th>
                                <th>सम्झौता मिति </th>
                                <th>कार्यसम्पन्न मिति</th>
                                <!--<th>#</th>-->
                                <th>दोस्रो पक्ष()</th>
                                <th>दोस्रो पक्षको सम्पर्क व्यक्ति</th>
                                <th>दोस्रो पक्षको सम्पर्क नम्बर</th>
                                <th>कैफियत</th>
                            </tr>
                            <?php $i = 1;
                            foreach ($quotation_result as $qr):
                                // echo "<pre>";print_r($quotation_result);exit;
                                $plan_details = Plandetails1::find_by_id($qr->plan_id);
                                $biniyojan = Topicareainvestment::getName($plan_details->topic_area_investment_id);
                                $more_details = Quotationmoredetails::find_by_plan_id($qr->plan_id);
                                $nepali_miti = DateEngToNep($more_details->miti);
                                $antim_bhuktani = Planamountwithdrawdetails::find_by_plan_id($qr->plan_id);
                                $mulyankan_bhuktani = Analysisbasedwithdraw::find_by_plan_id($qr->plan_id);
                                $mulyankan_bhuktani = $mulyankan_bhuktani[0];
                                // print_r($mulyankan_bhuktani);
                            
                                if (!empty($mulyankan_bhuktani)) {
                                    $total_plan_evaluated = $antim_bhuktani->plan_evaluated_amount + $mulyankan_bhuktani->evaluated_amount;
                                    $final_paid_amount = $antim_bhuktani->final_total_paid_amount + $mulyankan_bhuktani->total_paid_amount;
                                    $miti = '<div style="color:blue;font-weight:bold;">' . 'मुल्यांकन भुक्तानी भयको' . '</div>';
                                } elseif (!empty($antim_bhuktani)) {
                                    $total_plan_evaluated = $antim_bhuktani->plan_evaluated_amount;
                                    $final_paid_amount = $antim_bhuktani->final_total_paid_amount;
                                    $miti = '<div style="color:green;font-weight:bold;">' . $antim_bhuktani->plan_end_date . '</div>';
                                } else {
                                    $total_plan_evaluated = 0;
                                    $final_paid_amount = 0;
                                    $miti = '<div style="color:red;font-weight:bold;">' . 'सम्झौता मात्र भयको' . '</div>';
                                }

                                $quotation_enlist = Quotationenlist::find_by_sql("SELECT * FROM quotation_enlist_form WHERE plan_id = '" . $qr->plan_id . "' ORDER BY amount ASC LIMIT 1");
                                $new_val = ($quotation_enlist[0]);

                                if ($new_val->enlist_type == 10) {
                                    $enlist_name = Contractordetails::getName($new_val->enlist_id);
                                    $enlist_contact_no = Contractordetails::getNumber($new_val->enlist_id);
                                } elseif ($new_val->enlist_type == 0) {
                                    $enlist_name = Enlist::getName1($new_val->enlist_id);
                                    $enlist_contact_no = Enlist::getNumber($new_val->enlist_id);
                                } else {
                                    $enlist_name = "No Firm Selected";
                                    $enlist_contact_no = "No Firm Contact Numbers Selected";
                                }
                                ?>
                                <tr>
                                    <td><?= convertedcit($i); ?></td>
                                    <td><?= convertedcit($plan_details->id); ?></td>
                                    <td><?= $plan_details->program_name; ?></td>
                                    <td><?= $biniyojan ?></td>
                                    <td><?= convertedcit($plan_details->ward_no); ?></td>
                                    <td><?= convertedcit(placeholder($plan_details->investment_amount)); ?>/-</td>
                                    <td><?= convertedcit(placeholder($qr->kul_lagat_anudan)) ?>/-</td>
                                    <td><?= convertedcit(placeholder($total_plan_evaluated)) ?>/-</td>
                                    <td><?= convertedcit(placeholder($final_paid_amount)) ?>/-</td>
                                    <td><?= convertedcit($nepali_miti); ?></td>
                                    <td><?= convertedcit($miti); ?></td>
                                    <!--<td><?= $new_val->enlist_type; ?></td>-->
                                    <td><?= convertedcit($enlist_name . '( ' . $new_val->amount . ' )') ?></td>
                                    <td><?= $enlist_name ?></td>
                                    <td><?= convertedcit($enlist_contact_no); ?></td>
                                </tr>
                                <?php $i++;
                                $abc += $plan_details->investment_amount;
                                $xyz += $qr->kul_lagat_anudan;
                                $ksy += $total_plan_evaluated;
                                $sky += $final_paid_amount;
                            endforeach; ?>
                            <tr>
                                <td colspan="5">जम्मा</td>
                                <td><strong><u><?= convertedcit(placeholder($abc)) ?>/-</u></strong></td>
                                <td><strong><u><?= convertedcit(placeholder($xyz)) ?>/-</u></strong></td>
                                <td><strong><u><?= convertedcit(placeholder($ksy)) ?>/-</u></strong></td>
                                <td><strong><u><?= convertedcit(placeholder($sky)) ?>/-</u></strong></td>
                                <td colspan="6">&nbsp;</td>
                            </tr>
                        </table>
                    </div>
                </div>
            </div>
</body>
<script>
    window.print();
</script>