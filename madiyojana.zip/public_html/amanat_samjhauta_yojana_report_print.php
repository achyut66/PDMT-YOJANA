<?php require_once ("includes/initialize.php");
if (!$session->is_logged_in()) {
    redirect_to("logout.php");
}
$mode = getUserMode();
$counted_result = getOnlyRegisteredPlans($_GET['ward_no']);
if ($mode != "administrator" && $mode != "superadmin") {
    die("ACCESS DENIED");
}
if (empty($_GET['ward_no'])) {
    $upabhokta_result = AmanatLagat::find_all();
} else {
    $upabhokta_result = get_wardwise_result_sql($_GET['ward_no'], "amanat_lagat");
}
$plan_array = array();
foreach ($upabhokta_result as $data1) {
    array_push($plan_array, $data1->plan_id);
}
$count0 = count($plan_array);
//$total_investment0 = Plandetails1::get_total_investment_by_plan_ids(implode(",", $plan_array));
$result = Plandetails1::find_by_plan_id(implode(",", $plan_array));
$fiscal = Fiscalyear::find_by_sql("select * from fiscal_year where is_current = 1");
?>
<?php include ("menuincludes/header1.php"); ?>
<!-- js ends -->
<title>अमानत मार्फत सम्झौता print page:: <?php echo SITE_SUBHEADING; ?></title>
</head>
<style>
    body {
        overflow: visible !important;
    }
</style>

<body>
    <div class="myPrintFinal">
        <div class="userprofiletable">
            <div class="printPage">
                <div class="printlogo"><img src="images/emblem_nepal.png" alt="Logo"></div>
                <h1 class="marginright1"><?php echo SITE_LOCATION; ?></h1>
                <h4 class="marginright1"><?php echo SITE_HEADING; ?> </h4>
                <h5 class="marginright1"><?php echo SITE_ADDRESS; ?></h5>
                <div class="myspacer"></div>
                <?php foreach ($fiscal as $fiscal): ?>
                    <div class="subject"><b><u>आ.व. <strong><?= convertedcit($fiscal->year); ?></strong>अमानत मार्फत सम्झौता
                                भएको योजनाहरु</b></u> </div>
                <?php endforeach; ?>
                <div class="myspacer"></div>
                <table class="table table-bordered table-responsive">
                    <tr>
                        <td class="myCenter"><strong>सि.न </strong></td>
                        <td class="myCenter"><strong>दर्ता नं</strong></td>
                        <td class="myCenter"><strong>योजनाको नाम</strong></td>
                        <td class="myCenter"><strong>बिनियोजन किसिम</strong></td>
                        <td class="myCenter"><strong>वार्ड नं </strong></td>
                        <td class="myCenter"><strong>विनियोजित रु </strong></td>
                        <td class="myCenter"><strong>ईष्टिमेट रकम</strong></td>
                        <td class="myCenter"><strong>सम्झौता मिति </strong></td>
                        <td class="myCenter"><strong>भुक्तानी रकम (रु) </strong></td>
                        <td class="myCenter"><strong>कार्यसम्पन्न मिति</strong></t>
                        <td class="myCenter"><strong>दोस्रो पक्ष सम्पर्क व्यक्ति / ठेगाना / पद</strong></td>
                        <td class="myCenter"><strong>कैफियत</strong></td>
                    </tr>
                    <?php $i = 1;
                    foreach ($result as $re):
                        $baki = $re->investment_amount - $data1->bhuktani_anudan;
                        $estimate = AmanatLagat::find_by_plan_id($re->id);
                        $samjhauta_bibaran = Amanat_more_details::find_by_plan_id($re->id);
                        $antim_bhuktani = Planamountwithdrawdetails::find_by_plan_id($re->id);
                        // echo "<pre>";
                        // print_r($samjhauta_bibaran);exit;
                        ?>
                        <tr>
                            <td class="myCenter"><?php echo convertedcit($i); ?></td>
                            <td class="myCenter"><?php echo convertedcit($re->id); ?></td>
                            <td class="myCenter"><?php echo $re->program_name; ?></td>
                            <td class="myCenter"><?php echo Topicareainvestment::getName($re->topic_area_investment_id); ?>
                            </td>
                            <td class="myCenter"><?php echo convertedcit($re->ward_no); ?></td>
                            <td class="myCenter"><?= convertedcit($re->investment_amount); ?>/-</td>

                            <td class="myCenter">
                                <hr style="border">
                                <table class="table table-bordered">
                                    <tr>
                                        <td class="myCenter">जनश्रमदान</td>
                                        <td class="myCenter">उपभोक्ता नगद साझेदारी</td>
                                        <td class="myCenter">अन्य निकाय साझेदारी</td>
                                    </tr>
                                    <tr>
                                        <td><?= convertedcit(placeholder($estimate->costumer_investment)); ?>/-</td>
                                        <td><?= convertedcit(placeholder($estimate->costumer_agreement)); ?>/-</td>
                                        <td><?= convertedcit(placeholder($estimate->agreement_other)); ?>/-</td>
                                    </tr>
                                    <tr>
                                        <td class="myCenter"><strong>जम्मा इस्टिमेट</strong></td>
                                        <td class="myCenter" colspan="2">
                                            <strong><u><?= convertedcit(round($estimate->total_investment, 2)); ?>/-</u></strong>
                                        </td>
                                    </tr>
                                </table>

                            </td>
                            <td class="myCenter"><?= convertedcit($samjhauta_bibaran->miti); ?></td>
                            <td class="mycenter"><?= convertedcit($antim_bhuktani->final_total_paid_amount); ?>/-</td>
                            <?php if (!empty($antim_bhuktani->plan_end_date)) { ?>
                                <td class="myCenter"><?= convertedcit($antim_bhuktani->plan_end_date); ?></td>
                            <?php } else { ?>
                                <td class="myCenter" style="color:red">कार्य सम्पन्न नभयको</td>
                            <?php } ?>
                            <td class="myCenter">
                                <?= $samjhauta_bibaran->organizer_name . '<hr>' . $samjhauta_bibaran->organizer_name_address . '<hr>' . convertedcit($samjhauta_bibaran->organizer_name_post) ?>
                            </td>
                            <td class="myCenter"></td>
                        </tr>
                        <?php $amount_total += $estimate->costumer_investment;
                        $total_bhuktani += $estimate->costumer_agreement;
                        $abc += $estimate->agreement_other;
                        $estimated += $estimate->total_investment;
                        $total_baki += $baki;
                        $bhuktani_total += $antim_bhuktani->final_total_paid_amount;
                        $i++;
                    endforeach; ?>
                    <tr>

                        <td colspan="6" style="text-right">जम्मा </td>
                        <td>
                            <table class="table table-bordered">
                                <tr>
                                    <td>जम्मा श्रमदान</td>
                                    <td>जम्मा नगद साझेदारी</td>
                                    <td>जम्मा अन्य निकाय</td>
                                </tr>
                                <tr>
                                    <td><?= convertedcit(placeholder(round($amount_total, 2))); ?>/-</td>
                                    <td><?= convertedcit(placeholder(round($total_bhuktani, 2))); ?>/-</td>
                                    <td><?= convertedcit(placeholder(round($abc, 2))); ?>/-</td>
                                </tr>
                                <tr>
                                    <td style="font-weight:bold;">जम्मा इस्टिमेट </td>
                                    <td><strong><u><?= convertedcit(placeholder(round($estimated, 2))); ?>/-</u></strong>
                                    </td>
                                </tr>
                            </table>
                        </td>
                        <td><?php //echo convertedcit(placeholder($amount_total)); ?></td>
                        <td style="font-weight:bold;">
                            <?php echo convertedcit(placeholder(round($bhuktani_total), 2)); ?></td>
                        <td colspan="2"><?php //echo convertedcit(placeholder($total_baki)); ?></td>
                    </tr>
                </table>
                <div class="myspacer20"></div>
                <div class="oursignature">&nbsp</div>
                <div class="myspacer"></div>
            </div><!-- print page ends -->
        </div><!-- userprofile table ends -->
    </div><!-- my print final ends -->