var JQ = jQuery.noConflict();
JQ(document).ready(function () {
    // Function to create a chart
    function createChart(ctx, chartType, labels, datasetLabel, data, backgroundColor) {
        var chardata = {
            labels: labels,
            datasets: [{
                label: datasetLabel,
                backgroundColor: backgroundColor,
                data: data,
            }],
        };

        var options = {
            title: {
                display: true,
                position: 'top',
                text: datasetLabel,
                fontSize: 20,
                fontColor: "#333",
            },
            legend: {
                display: false,
                position: 'bottom',
            },
            scales: {
                yAxes: [{
                    ticks: {
                        beginAtZero: true,
                    },
                }],
            },
        };

        return new Chart(ctx, {
            type: chartType,
            data: chardata,
            options: options,
        });
    }

    // AJAX requests
    JQ.ajax({
        url: "get_yojana_report.php",
        method: "post",
        success: function (data) {
            var obj = JSON.parse(data);
            var yojana = [];
            var count = [];
            var bgcolors = [];
            var hbcolors = [];

            for (var i in obj) {
                yojana.push(obj[i].yojana);
                count.push(obj[i].count);
                bgcolors.push("rgba(" + obj[i].color + ", 0.75)");
                hbcolors.push("rgba(" + obj[i].color + ", 1)");
            }

            var ctx = JQ("#yojana_report");
            createChart(ctx, 'doughnut', yojana, 'संख्या', count, bgcolors);
        },
        error: function (data) {
            console.log(data);
        },
    });

    JQ.ajax({
        url: "get_karyakam_report.php",
        method: "post",
        success: function (data) {
            var obj = JSON.parse(data);
            var yojana = [];
            var count = [];
            var bgcolors = [];
            var hbcolors = [];

            for (var i in obj) {
                yojana.push(obj[i].yojana);
                count.push(obj[i].count);
                bgcolors.push("rgba(" + obj[i].color + ", 0.75)");
                hbcolors.push("rgba(" + obj[i].color + ", 1)");
            }

            var ctx = JQ("#yojana_report1");
            createChart(ctx, 'bar', yojana, 'संख्या', count, bgcolors);
        },
        error: function (data) {
            console.log(data);
        },
    });

    JQ.ajax({
        url: "get_yojana_report.php",
        type: "POST",
        success: function (data) {
            var obj = JSON.parse(data);
            var yojana = [];
            var anudan = [];
            var kharcha = [];
            var baki = [];

            for (var i in obj) {
                yojana.push(obj[i].yojana);
                anudan.push(parseInt(obj[i].anudan));
                kharcha.push(parseInt(obj[i].kharcha));
                baki.push(parseInt(obj[i].baki));
            }

            var ctx = JQ("#yojana_report2");
            var chart = createChart(ctx, 'bar', yojana, 'संख्या', anudan, 'blue');
            createChart(ctx, 'bar', yojana, 'हाल सम्मको खर्च', kharcha, 'red');
            createChart(ctx, 'bar', yojana, 'बाकी रकम', baki, 'green');
        },
        error: function (data) {
            console.log(data);
        },
    });

    JQ.ajax({
        url: "get_yojana_bikash_report.php",
        type: "GET",
        success: function (data) {
            var obj = JSON.parse(data);
            var topic = [];
            var count = [];
            var hbcolors = [];
            var bgcolors = [];

            for (var i in obj) {
                topic.push(obj[i].topic);
                count.push(parseInt(obj[i].count));
                bgcolors.push("rgba(" + obj[i].color + ", 0.75)");
                hbcolors.push("rgba(" + obj[i].color + ", 1)");
            }

            var ctx = JQ("#yojana_report3");
            createChart(ctx, 'doughnut', topic, 'कुल संख्या', count, bgcolors);
        },
        error: function (data) {
            console.log(data);
        },
    });
});
