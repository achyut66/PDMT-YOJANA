<?php require_once("includes/initialize.php");
if (!$session->is_logged_in()) {
    redirect_to("logout.php");
} ?>
<?php include("menuincludes/header.php"); ?>
<?php
if (isset($_POST['submit'])) {
    for ($i = 0; $i < count($_POST['topic']); $i++) {
        $kar_bibran = new LawsAndRules();
        $kar_bibran->name = $_POST['name'][$i];
        $kar_bibran->marfat = $_POST['marfat'][$i];
        $kar_bibran->aindafa = $_POST['aindafa'][$i];
        $kar_bibran->save();
    }
    if (isset($_POST['update_id']) && !empty($_POST['update_id'])) {
        $form_data = LawsAndRules::find_by_id($_POST['update_id']);
    } else {
        $form_data = new LawsAndRules();
    }
    $form_data->name = $_POST['name'];
    $form_data->marfat = $_POST['marfat'];
    $form_data->aindafa = $_POST['aindafa'];
    // pp($form_data);exit;
    if ($form_data->save()) {
        echo alertBox("डाटा सेव भयो ||", "rulesandlaws.php");
    }
}
if (isset($_GET['id'])) {
    $data = LawsAndRules::find_by_id($_GET['id']);
} else {
    $data = LawsAndRules::setEmptyObjects();
}
$budget_result = LawsAndRules::find_all();
?>
<!-- js ends -->
<title>दफा लेख्नुहोस :
    <?php echo SITE_SUBHEADING; ?>
</title>
</head>

<body>
    <?php include("menuincludes/topwrap.php"); ?>
    <div id="body_wrap_inner">
        <div class="maincontent">
            <h2 class="headinguserprofile">दफा लेख्नुहोस | <a href="settings.php" class="btn">पछि जानुहोस </a></h2>
            <div class="myMessage">
                <?php echo $message; ?>
            </div>
            <div class="OurContentFull">
                <h2>दफा विवरण</h2>
                <div class="userprofiletable">
                    <form method="post" enctype="multipart/form-data">
                        <div class="inputWrap">
                            <div class="titleInput">योजना संचालन प्रकृति</div>
                            <div class="newInput">
                                <select class="form-control" name="marfat">
                                    <option value="0">---छानुहोस---</option>
                                    <option value="1">उपभोक्ता समिति</option>
                                    <option value="2">कार्यक्रम मार्फत</option>
                                    <option value="3">ठेक्का मार्फत</option>
                                    <option value="4">संस्था समिति</option>
                                    <option value="5">कोटेसन मार्फत</option>
                                    <option value="6">अमानत मार्फत</option>
                                    <option value="7">ई-ठेक्का मार्फत</option>
                                    <option value="8">Heavy Equipment</option>
                                </select>
                            </div>
                            <div class="titleInput">ऐन / नियम के हो ?</div>
                            <div class="newInput">
                                <select class="form-control" name="aindafa">
                                    <option>---छानुहोस---</option>
                                    <option value="1">ऐन</option>
                                    <option value="2">कार्यविधि</option>
                                </select>
                            </div>
                            <!-- <div> -->
                            <div class="titleInput">बिषय</div>
                            <div class="newInput"><input type="text" name="name" value="<?php echo $data->name; ?>"
                                    required></div>
                            <div class="saveBtn myWidth100"><input type="submit" name="submit" value="सेभ गर्नुहोस"
                                    class="btn">
                                <input type="hidden" name="update_id" value="<?= $data->id ?>" />
                            </div>
                            <div class="myspacer"></div>
                        </div><!-- input wrap ends -->

                    </form>
                    <table class="table table-bordered table-hover">
                        <tr>
                            <td class="myCenter"><strong>सि.नं.</strong></td>
                            <td class="myCenter"><strong>नियमावली / कार्यविधि</strong></td>
                            <td class="myCenter"><strong>ऐन / कार्यविधि</strong></td>
                            <td class="myCenter"><strong>मार्फत</strong></td>
                            <td></td>
                        </tr>
                        <?php $i = 1;
                        foreach ($budget_result as $result):
                            ?>
                            <?php
                            if ($result->marfat == 1) {
                                $kar_name = "उपभोक्ता";
                            } elseif ($result->marfat == 2) {
                                $kar_name = "कार्यक्रम";
                            } elseif ($result->marfat == 3) {
                                $kar_name = "ठेक्का";
                            } elseif ($result->marfat == 4) {
                                $kar_name = "संस्था";
                            } elseif ($result->marfat == 5) {
                                $kar_name = "कोटेसन";
                            } elseif ($result->marfat == 6) {
                                $kar_name = "अमानत";
                            } elseif ($result->marfat == 7) {
                                $kar_name = "ई-ठेक्का";
                            } else {
                                $kar_name = "हेभी इक्युपमेन्ट";
                            }

                            if ($result->aindafa == 1) {
                                $ainkanun = "ऐन / नियम";
                            } else {
                                $ainkanun = "कार्यविधि";
                            }
                            ?>
                            <tr>
                                <td class="myCenter">
                                    <?php echo convertedcit($i); ?>
                                </td>
                                <td class="myCenter">
                                    <?php echo convertedcit($result->name); ?>
                                </td>
                                <td class="myCenter">
                                    <?= $ainkanun; ?>
                                </td>
                                <td class="myCenter">
                                    <?php echo $kar_name . ' मार्फत'; ?>
                                </td>
                                <form method="post" action="edit_rules.php">
                                    <td class="myCenter">
                                        <input type="hidden" name="id" value="<?= $result->id ?>">
                                        <span><button class="button btn-primary">सच्याउनुहोस</button></span>
                                </form>
                                <form method="post" action="katti_delete.php">
                                    <span><button class="button btn-danger">हटाउनुहोस</button></span>
                                    <input type="hidden" name="id" value="<?= $result->id ?>">
                                </form>

                                </td>

                            </tr>
                            <?php $i++;
                        endforeach; ?>
                    </table>
                </div>
            </div>
        </div><!-- main menu ends -->
    </div><!-- top wrap ends -->
    <?php include("menuincludes/footer.php"); ?>