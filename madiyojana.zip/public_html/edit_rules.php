<?php require_once("includes/initialize.php");
if(!$session->is_logged_in()){ redirect_to("logout.php");}?>
<?php include("menuincludes/header.php"); ?>
<?php
$result = LawsAndRules::find_by_id($_POST['id']);

if(isset($_POST['submit']))
{
    $data = LawsAndRules::find_by_id($_POST['id']);
    $data->name= $_POST['name'];
    $data->marfat= $_POST['marfat'];
    $data->aindafa = $_POST['aindafa'];
    // pp($data);exit;
    if($data->save())
    {
        $session->message("डाटा सेव भयो ||");
        redirect_to("rulesandlaws.php");
    }
}

// pp($result);
?>
    <!-- js ends -->
    <title>ऐन दफा सच्याउनुहोस:: <?php echo SITE_SUBHEADING;?></title>
    </head>
    <body>
<?php include("menuincludes/topwrap.php"); ?>
    <div id="body_wrap_inner">
        <div class="maincontent">
            <h2 class="headinguserprofile">ऐन दफा | <a href="settings_unit.php" class="btn">पछि जानुहोस</a></h2>
            <div class="OurContentFull">
                <div class="myMessage">
                    <?php echo $message;?>
                </div>
                <?php              
                                    if($result->marfat==1){
                                        $kar_name = "उपभोक्ता";
                                    }elseif($result->marfat==2){
                                        $kar_name = "कार्यक्रम";
                                    }elseif($result->marfat==3){
                                        $kar_name = "ठेक्का";
                                    }elseif($result->marfat==4){
                                        $kar_name = "संस्था";
                                    }elseif($result->marfat==5){
                                        $kar_name = "कोटेसन";
                                    }elseif($result->marfat==6){
                                        $kar_name = "अमानत";
                                    }else{
                                        $kar_name = "ई-ठेक्का";
                                    }

                                    if($result->aindafa==1){
                                        $ainkanun = "ऐन";
                                    }else{
                                        $ainkanun = "दफा";
                                    }
                                    ?>
                <h2>ऐन दफा </h2>
                <div class="userprofiletable">
                    <form method="post" enctype="multipart/form-data">
                        <div class="inputWrap">
                            <div class="titleInput">योजना संचालन प्रकृति : </div>
                            <div class="newInput">
                                        <select class="form-control" name="marfat">
                                            <option>---छानुहोस---</option>
                                            <option value="1" <?php if($result->marfat==="1"){echo "selected='selected'";} ?>>उपभोक्ता समिति</option>
                                            <option value="2" <?php if($result->marfat==="2"){echo "selected='selected'";} ?>>कार्यक्रम मार्फत</option>
                                            <option value="3" <?php if($result->marfat==="3"){echo "selected='selected'";} ?>>ठेक्का मार्फत</option>
                                            <option value="4" <?php if($result->marfat==="4"){echo "selected='selected'";} ?>>संस्था समिति</option>
                                            <option value="5" <?php if($result->marfat==="5"){echo "selected='selected'";} ?>>कोटेसन मार्फत</option>
                                            <option value="6" <?php if($result->marfat==="6"){echo "selected='selected'";} ?>>अमानत मार्फत</option>
                                            <option value="7" <?php if($result->marfat==="7"){echo "selected='selected'";} ?>>ई-ठेक्का मार्फत</option>
                                        </select>
                                    </div>
                            <!--<div class="newInput"><input type="text" id="topic_name" name="name" value="<?php echo $laws->marfat; ?>"></div>-->
                            <div class="titleInput">ऐन वा दफा के हो ? : </div>
                            <div class="newInput">
                                        <select class="form-control" name="aindafa"?>
                                            <option>---छानुहोस---</option>
                                            <option value="1" <?php if($result->aindafa==="1") { echo "selected='selected'";} ?>>ऐन</option>
                                            <option value="2" <?php if($result->aindafa==="2") { echo "selected='selected'";} ?>>दफा</option>
                                        </select>
                                    </div>
                            <!--<div class="newInput"><input type="text" id="topic_alias" name="alias" value=""></div>-->
                            <div class="titleInput">बिषय</div>
                            <div class="newInput"><input type="text" name="name" value="<?=$result->name?>"></div>
                            <div class="saveBtn myWidth100"><input type="submit" name="submit" value="सेभ गर्नुहोस" class="btn"></div>
                            <input type="hidden" value="<?php echo $result->id; ?>" name="id" />
                            <div class="myspacer"></div>
                        </div><!-- input wrap ends -->
                    </form>
                </div>
            </div>
        </div><!-- main menu ends -->
    </div><!-- top wrap ends -->
<?php include("menuincludes/footer.php"); ?>