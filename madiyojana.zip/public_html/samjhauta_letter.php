<?php require_once("includes/initialize.php"); 
if(!$session->is_logged_in()){ redirect_to("logout.php");}
if(!isset($_GET['id']) && isset($_SESSION['set_plan_id']))
{
  redirectUrl();
}
$datas=Samiticostumerassociationdetails::find_by_plan_id($_GET['id']);
$worker= Samitimoreplandetails::find_by_plan_id($_GET['id']);
// print_r($worker);
$data=  Plandetails1::find_by_id($_GET['id']);
$fiscal = FiscalYear::find_by_id($data->fiscal_id);
$ward_address=WardWiseAddress();
$address= getAddress();	
include("menuincludes/header.php"); 
?>
<!-- js ends -->
<title>योजना संझौता फाराम print page:: <?php echo SITE_SUBHEADING;?></title>
<style>
                          table {

                            width: 100%;
                            border: none;
                          }
                          #div_new{
                            background-image: url("images/nepali_paper.jpg");
                          }
                        </style>
</head>
<body>
    <?php include("menuincludes/topwrap.php"); ?>
    <div id="body_wrap_inner"> 
    	<div class="maincontent" id="div_new">
    	    <form method="get" action="samjhauta_letter_final.php?>">
                    <h2 class="headinguserprofile">योजना संझौता फाराम | <a href="samiti_letters_select.php" class="btn">पछि जानुहोस </a>
                    <div class="myPrint"><input type="hidden" name="id" value="<?=$_GET['id']?>" /><input type="submit" value="प्रिन्ट" name="submit" /></div>
                    </h2>
                    <div class="OurContentFull">
                        <!--<div class="myPrint"><a href="samjhauta_letter_final.php" target="_blank">प्रिन्ट गर्नुहोस</a></div>-->
                        <div class="userprofiletable">
                        	<div class="printPage">
									<div class="image-wrapper">
                                    <a href="#" ><img src="images/janani.png" align="left" class="scale-image"/></a>
                                    <div />
                                    
                                    <div class="image-wrapper">
                                    <a href="#" target="_blank" ><img src="images/bhaire.png" align="right" class="scale-image"/></a>
                                    <div />
									<?php include("menuincludes/letter_head.php");?>
									<div class="myspacer"></div>
									<div class="printContent">
                                         <div class="mydate">मिति : <?php echo convertedcit($worker->miti); ?></div>
                                        <div class="patrano">आर्थिक वर्ष : <?php echo convertedcit($fiscal->year); ?></div>
										<div class="patrano"> योजना दर्ता नं : <?php echo convertedcit($_GET['id']) ?>	</div>
                                       
                                        <div class="myspacer"></div>
										
										<div class="banktextdetails1">
                                        	<h4>योजना संझौता फाराम</h4>
                                              <div class="mycontent" >
                     <table class="table table-bordered table-responsive">
                                        
                                      <tr>
                                            <td class="myWidth50 myTextalignRight">योजनाको नाम</td>
                                            <td><?php echo $data->program_name;?></td>
                                          </tr>
                                      <tr>
                                      <tr>
                                            <td class="myTextalignRight">आयोजना सचालन हुने स्थान / वार्ड नं</td>
                                            <td><?php echo SITE_LOCATION;?>- <?php echo convertedcit($data->ward_no);?></td>
                                          </tr>
                                      <tr>
                                                <td class="myTextalignRight">योजनाको बिषयगत क्षेत्रको नाम</td>
                                                <td><?php echo Topicarea::getName($data->topic_area_id); ?></td>
                                          </tr>
                                           <tr>
                                               <td class="myTextalignRight">योजनाको  शिर्षकगत नाम </td>
                                               <td><?php echo Topicareatype::getName($data->topic_area_type_id); ?></td>
                                           </tr>
                                           <tr>
                                               <td class="myTextalignRight">योजनाको  उपशिर्षकगत नाम</td>
                                               <td><?php echo Topicareatypesub::getName($data->topic_area_type_sub_id); ?></td>
                                           </tr>                                       
                                           <tr>
                                               <td class="myTextalignRight">योजनाको अनुदानको किसिम</td>
                                               <td><?php echo Topicareaagreement::getName($data->topic_area_agreement_id); ?></td>
                                          </tr> 
                                          <tr>
                                               <td class="myTextalignRight">योजनाको विनियोजन किसिम</td>
                                               <td><?php echo Topicareainvestment::getName($data->topic_area_agreement_id); ?></td>
                                          </tr>
                                          
                                           
                                           
                                           <tr>
                                            <td class="myTextalignRight">अनुदान रु</td>
                                            <td>रु. <?php echo convertedcit($data->investment_amount);?></td>
                                           </tr>
                       </table>
                     </div>
                                                <?php $data=  Samitiplantotalinvestment::find_by_plan_id($data->id);
                                                if(empty($data))
                                                {?>
                                                  <h4> योजनाको कुल लागत अनुमान भरिएको छैन</h4>
                                                  
                                                <?php exit; }
                                                else
                                                {
                                                ?>
                                              <h4> योजनाको कुल लागत अनुमान </h4>
                                              <div class="mycontent" >
                                                  <table class="table table-bordered table-responsive">
                                                    <?php 
                                                       
                                                        $unit = Units::find_by_id($data->unit_id);
                                                    ?>
                                                      <td class="myTextalignRight"><?php echo SITE_TYPE;?>बाट अनुदान</td>
                                                      <td>रु.  <?php echo convertedcit($data->agreement_gauplaika);?></td>
                                                    </tr>
                                                    <tr>
                                                      <td class="myTextalignRight">अन्य निकायबाट प्राप्त अनुदान</td>
                                                      <td>रु. <?php echo convertedcit($data->agreement_other);?></td>
                                                    </tr>
                                                    <tr>
                                                      <td class="myTextalignRight">संस्था / समितिबाट नगद साझेदारी</td>
                                                      <td>रु. <?php echo convertedcit($data->costumer_agreement);?></td>
                                                    </tr>
                                                    <tr>
                                                      <td class="myTextalignRight">अन्य साझेदारी</td>
                                                      <td>रु. <?php echo convertedcit($data->other_agreement);?></td>
                                                    </tr>
                                                    <tr>
                                                      <td class="myTextalignRight">संस्था / समितिबाट जनश्रमदान</td>
                                                      <td>रु. <?php echo convertedcit($data->costumer_investment);?></td>
                                                    </tr>
                                                    <tr>
                                                      <td class="myTextalignRight">कुल लागत अनुमान जम्मा </td>
                                                      <td>रु. <?php echo convertedcit($data->total_investment);?></td>
                                                    </tr>
                                                   
                                                  </table>
                                                </div>
                                                <?php } ?>
                                                <!-- <div class="text-center"><strong></strong></div> -->
                                                <p style="text-align:center;font-size:18;">भौतिक परिमाणको शिर्षक</p>
                                              <table class="table table-bordered table-responsive">
                                                  <th>सी.नं</th>
                                                  <th>परिमाणको शिर्षक</th>
                                                  <th>परिमाण</th>
                                                  <th>भौतिक इकाई</th>
                                                  <?php 
                                                  $b_l = Bhautik_lakshya::find_by_plan_id_and_type($_GET['id'],1);//print_r($b_l);
                                                  $i = 1; foreach($b_l as $b_l):
                                                  //print_r($b_l);  
                                                  ?>
                                                  <tr>
                                                      <td><?php echo convertedcit($i);?></td>
                                                      <td><?php echo SettingbhautikPariman::getName($b_l->details_id);?></td>
                                                      <td><?php echo convertedcit($b_l->qty);?></td>
                                                      <td><?php echo Units::getName($b_l->unit_id);?></td>
                                                  </tr>
                                                  <?php $i++;endforeach;?>
                                              </table>
                                              <?php 
                                              $data2=  Samiticostumerassociationdetails0::find_by_plan_id($_GET['id']);
                                              if(empty($data2)){?>
                                                  <h4>संस्था / समिति सम्बन्धी विवरण भरिएको छैन </h4>
                                             <?php
                                              }
                                              else
                                              {
                                              ?>
                                              <h4>संस्था / समिति समिति  सम्बन्धी विवरण </h4>
                                              <div class="mycontent">
                                                    <table class="table table-bordered table-responsive">
                                                        <?php 
                                                        $data3=  Samiticostumerassociationdetails::find_by_plan_id($_GET['id']);?>
                                                        <tr>
                                                            <td> योजनाको संचालन गर्ने संस्था / समितिको नाम:<u><?php echo $data2->program_organizer_group_name;?> </u></td>  
</tr> 
                                                            
<tr>
<td> ठेगाना: <u> <?php echo SITE_NAME. convertedcit($data2->program_organizer_group_address);?></u></td>
                                                    </tr>
                                                    </table>
                                                  <div class="" style="text-align: center">संस्था समिति विवरण</div>
                                                    <table class="table table-bordered table-responsive">
                                                        <tr>
                                                            <td class="myCenter"><strong>सि.नं.</strong></td>
                                                            <td class="myCenter"><strong>नामथर</strong></td>
                                                            <td class="myCenter"><strong>पद</strong></td>
                                                            <td class="myCenter"><strong>मोवायल नं</strong></td>
                                                        </tr>
                                                     <?php $i=1;foreach($data3 as $data):?>
                                                        <tr>
                                                            <td class="myCenter"><?php echo convertedcit($i);?></td>
                                                            <td class="myCenter"><?php echo $data->name?> </td>
                                                            <td class="myCenter"><?php echo $data->cit_no?></td>
                                                            <td class="myCenter"><?php echo convertedcit($data->mobile_no);?></td>
                                                        </tr>
                                                        <?php $i++; endforeach;?>
                                                    </table>
                                                </div>
                                              <?php } ?>
                                              <?php $data= Samitimoreplandetails::find_by_plan_id($_GET['id']); 
                                              if(empty($data)){?>
                                                <h4 >योजना सम्बन्धी अन्य विवरण भरिएको छैन</h4>
                                              <?php }else{?>
                                              <h4 >योजना सम्बन्धी अन्य विवरण</h4>
                                              <div class="mycontent">
                                                  <table class="table table-bordered table-hover">
                                                      <?php $data= Samitimoreplandetails::find_by_plan_id($_GET['id']); ?>
                                                      <tr>
                                                            <td >संस्था / समिति गठन भएको मिति :</td>
                                                            <td ><?php echo convertedcit($data->miti);?></td>
                                                          </tr>
                                                          <tr>
                                                            <td>योजना शुरु हुने मिति</td>
                                                            <td><?php echo convertedcit($data->yojana_start_date);?></td>
                                                          </tr>
                                                          <tr>
                                                            <td>योजना सम्पन्न हुने मिति</td>
                                                            <td><?php echo convertedcit($data->yojana_sakine_date);?></td>
                                                          </tr>
                                                          
                                                   </table>
                                                   </div>
                            <h3 > योजनाबाट लाभान्वित घरधुरी तथा परिबारको विबरण</h3>
                          <table class="table table-bordered table-responsive">
                                <tr>
                                 <td colspan="5" class="myCenter">लाभान्वित जनसंख्या</td>
                                </tr>
                                <tr>
                                	
                                        <td class="myCenter">घर परिवार संख्या</td>
                                      <td class="myCenter">महिला</td>
                                      <td class="myCenter">पुरुष</td>
                                      <td class="myCenter">जम्मा</td>
                                    </tr>
                                    <?php $data= Samitiprofitablefamilydetails::find_by_type_id(0,$_GET['id']);?>
                                 <tr>

                                      <td class="myCenter"><?php echo convertedcit($data->pariwar_population);?></td>
                                     <td class="myCenter"><?php echo convertedcit($data->female);?></td>
                                      <td class="myCenter"><?php echo convertedcit($data->male);?></td>
                                      <td class="myCenter"><?php echo convertedcit($data->total);?></td>
                                  </tr>
                          </table>
                                              <?php }?>
                             </div>
                            </div><!-- yojana ends -->
                            			<div class="" style="margin:5px; font-size:15px;">
                            			    	  <h4>सम्झौताका शर्तहरु</h4>
                                              <ul>
                                                 <li>सम्झौतामा उल्लेख भएको म्याद भित्र संस्था / समितिले योजना सम्पन्न गरिसक्नु पर्ने छ । कुनै कारणवश योजना सम्पन्न हुन नसकेमा सम्पन्न हुन नसक्नुको कारण सहित म्याद सकिने अबधि भन्दा ७ दिन अगाबै संस्था / समितिलिे सम्बन्धित स्थानिय तहमा निबेदन दिनु पर्नेछ ।निबेदन प्राप्त भएपछि औचित्यको आधारमा निर्णय गरी सम्झौताको म्याद थप गर्न सकिनेछ । यसरी म्याद थप नगरी भुक्तानी उपलब्ध हुने छैन ।</li>
                                                 <li>योजनाको भुक्तानी स्थानीय तहले प्राबिधिक रनिङ बिलको आधारमा किस्ताको रुपमा वा काम सम्पन्न भएपछि संस्था / समितिले खर्चको विवरण मुल समिति र अनुगमन समितिको बैठक बसी  आम्दानी खर्च  सार्बजनिक गरी अनुमोदन गरेपछि मात्र  उपलब्ध गराइने छ ।</li>
        <li>
        तोकिएको काम भन्दा कम काम गर्ने वा काम नै नगरी वा वास्तविक काम भन्दा बढी काम गरेको देखाई अथवा कुनै आइटमको सट्टा अर्को आइटमको कार्य पूरा गरेको देखाई लागत अनुमानभन्दा फरक काम गरी  रकम माग्ने संस्था / समितिलाई उक्त रकम भुक्तानी नदिई कालो सूचीमा राखी  कारवाही गरिनेछ ।</li>
        <li>
        योजना संग सम्बन्धित प्राप्त नगद⁄जिन्सी संस्था / समितिले सम्बन्धित योजनामा मात्र खर्च गर्नु पर्नेछ र प्राप्त नगद⁄जिन्सीको दुरुपयोग, हिनामिना वा हानी नोक्सानी गरेमा प्रचलित कानुन बमोजिम कारवाही हुनेछ ।</li>
        <li>
        संस्था / समितिले काम सम्पन्न गरिसकेपछि बाँकि रहन गएका खप्ने सामानहरु मर्मत सम्भार समिति गठन भएको भए सो समितिलाई र सो नभए सम्बन्धित स्थानीय तहलाई बुझाउनु पर्नेछ । तर मर्मत सम्भार समितिलाई बुझाएको सामानको विवरणको एक प्रति सम्बन्धित <?php echo SITE_TYPE;?>मा बुझाउनु पर्नेछ ।</li>
        <li>
        संस्था / समितिले योजनासंग सम्बन्धित विल भर्पाइहरु, डोर हाजिरी फारामहरु, जिन्सी नगदी खाताहरु,समितिको निर्णय पुस्तिका आदि कागजात <?php echo SITE_TYPE;?> वा अन्य सरोकारवाला पदाधिकारीले मागेको बखत उपलब्ध गराउनु पर्ने छ र त्यसको लेखा परीक्षण पनि गराउन सकिनेछ ।</li>
        <li>
        योजनाको सार्वजनिक परीक्षण, सुचना पाटी, आम्दानी खर्चको सार्वजनिकरण, तथा अन्य पारदर्शिता सम्बन्धी प्रावधानको पालना गर्नु पर्नेछ।</li>
        <li>
       संस्था / समितिले कार्यदेश लिएर लामो समय सम्म योजना संचालन नगर्ने, योजनाको आय व्ययको विवरण दुरुस्त नराखी रकमको दुरुपयोग गरेमा सरकारी बाँकि सरह असुल उपर गरिने छ ।</li>
        <li>
        योजना सम्पन्न भएपछि स्थानीय तहबाट जाँच पास गरी फरफारकको प्रमाण पत्र लिनु पर्दछ ।साथै योजना हस्तान्तरण लिई आवश्यक मर्मत संभारको व्यवस्था सम्बन्धित उपभोक्ताहरुले नै गर्नु पर्नेछ।</li>
        <li>यस संझौतामा उल्लेख नभएका कुराहरु प्रचलित कानुन अनुसार हुनेछ।</li>
        <li>योजनाको लागि चाहिने आवश्यक कागजात यसै साथ संलग्न गरिएकोछ ।</li>
        <li>संस्था / समितिको पदाधिकारीहरुको नागरिकताको प्रतिलिपि संलग्न गरेका छौ ।
        </li>
        <li>
            <?php $rule= Rule::find_by_plan_id($_GET['id']);//print_r($rule);?>
            <?php foreach($rule as $rule):?>
            <?php echo $rule->rule;?>
            <?php endforeach;?>
        </li>
        </ul><!-- samjhauta list ends -->
                            			</div>
                                              <h4>माथि उल्लेख भए बमोजिमका शर्तहरु पालना गर्न हामी निम्न पक्षहरु मन्जुर गर्दछौं ।</h4>
                                            <div class="" style="text-align: center">संस्था समितिको तर्फबाट</div>
                                              <div class="mycontent">
                                              	<table class="table table-bordered table-hover">
                                              	<tr>
                                                	<td class="myWidth10 myCenterr">सि. नं</td>
                                                    <td class="myWidth20 myCenter">पद</td>
                                                    <td class="myWidth20 myCenter">नाम/थर</td>
                                                    <td class="myWidth25 myCenter">मोबाइल नं</td>
                                                    <td class="myWidth25 myCenter">दस्तखत</td>
                                                </tr>
                                                    <?php $i=1; foreach($data3 as $d3):?>
                                                    <tr>
                                                        <td class="myCenter"><?php echo convertedcit($i)?></td>
                                                        <td class="myCenter"><?php echo $d3->cit_no?></td>
                                                        <td class="myCenter"><?php echo $d3->name?></td>
                                                        <td class="myCenter"><?php echo $d3->mobile_no?></td>
                                                        <td></td>
                                                    </tr>
                                                    <?php $i++;endforeach;?>
                                                </table>
                                              </div><!-- upabhokta ends -->
                                              <h4>स्थानीय तहको तर्फबाट</h4>
                                              <div class="mycontent">
                                              	<table class="table table-bordered table-hover">
                                                	<tr>
                                                    	<td class="myWidth25 myCenter">सि.नं</td>
                                                        <td class="myWidth25 myCenter">पद</td>
                                                        <td class="myWidth25 myCenter">नामथर</td>
                                                        <td class="myWidth25 myCenter">दस्तखत</td>
                                                    </tr>
                                                    <tr>
                                                    	<td class="myCenter">१</td>
                                                        <td class="myCenter"><?php echo $worker->post_id_3;?></td>
                                                        <td class="myCenter"><?php echo Workerdetails::getName($worker->samjhauta_party);?></td>
                                                        <td class="myCenter">&nbsp;</td>
                                                    </tr>
                                                    <tr>
                                                    	<td colspan="2" class="text-right">मिति</td>
                                                        <td colspan="2"><?php echo convertedcit($worker->miti); ?></td>
                                                    </tr>
                                                </table>
                                              </div>
                                              
											
										</div><!-- bank details ends -->
										<div class="myspacer"></div>
										
									</div>
                                <!--<div class="settingsMenu1"><a href="settings_topic_add_sub.php">सह शिर्षक थप्नुहोस +</a></div>-->
                            </div>
                        </div>
                  </div>
                  </form>
                </div><!-- main menu ends -->
            
    </div><!-- top wrap ends -->
    <?php include("menuincludes/footer.php"); ?>