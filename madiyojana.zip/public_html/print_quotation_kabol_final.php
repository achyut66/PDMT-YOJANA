<?php require_once("includes/initialize.php");
if (!$session->is_logged_in()) {
    redirect_to("logout.php");
}
if (!isset($_GET['id']) && isset($_SESSION['set_plan_id'])) {
    redirectUrl();
}
$ward_address = WardWiseAddress();
$address = getAddress();
$datas = Bankinformation::find_all();
$workers = Workerdetails::find_all();
$url = $_GET['url'];
$date_selected= $_GET['date_selected'];
$user = getUser();
$print_history = PrintHistory::find_by_url_and_plan_id($url, $_GET['id']);
$print_date = PrintHistory::find_by_url_and_plan_id("quotation_dar_rate.php", $_GET['id']);
$quotation_total_investment = Quotationtotalinvestment::find_by_plan_id($_GET['id']);
$quotation_more_details = Quotationmoredetails::find_by_plan_id($_GET['id']);
$quotation_enlist = Quotationenlist::find_by_plan_id($_GET['id']);
$count = count($quotation_enlist);
$print_history = PrintHistory::find_by_url_and_plan_id($url, $_GET['id']);
if(empty($print_history))
{
    $print_history = new PrintHistory;
}
$print_history->url = $_GET['url'];
$print_history->nepali_date = $date_selected;
$print_history->english_date = DateNepToEng($date_selected);
$print_history->user_id = $user->id;
$print_history->plan_id = $_GET['id'];
$print_history->worker1 = $_GET['worker1'];
$print_history->worker2 = $_GET['worker2'];
$print_history->worker3 = $_GET['worker3'];
$print_history->worker4 = $_GET['worker4'];
$print_history->save();
if (!empty($print_history)) {
    $worker1 = Workerdetails::find_by_id($print_history->worker1);

} else {
    $print_history = PrintHistory::setEmptyObject();
    if (empty($worker1)) {
        $worker1 = Workerdetails::setEmptyObject();
    }

}
if(!empty($_GET['worker1']))
{
    $worker1 = Workerdetails::find_by_id($_GET['worker1']);
}
else
{
    $worker1 = Workerdetails::setEmptyObject();
}
if(!empty($_GET['worker2']))
{
    $worker2 = Workerdetails::find_by_id($_GET['worker2']);
}
else
{
    $worker2 = Workerdetails::setEmptyObject();
}
if(!empty($_GET['worker3']))
{
    $worker3 = Workerdetails::find_by_id($_GET['worker3']);
}
else
{
    $worker3 = Workerdetails::setEmptyObject();
}
if(!empty($_GET['worker4']))
{
    $worker4 = Workerdetails::find_by_id($_GET['worker4']);
}
else

{
    $worker4 = Workerdetails::setEmptyObject();
}
?>
<?php include("menuincludes/header1.php"); ?>

<!-- js ends -->
<title>कोटेसन्:: <?php echo SITE_SUBHEADING; ?></title>
<!-- <style>
    #div_new{
        background-image: url("images/nepali_paper.jpg");
        height: 150%;
    }
</style> -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"
        integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl"
        crossorigin="anonymous"></script>
</head>

<body>

<div id="body_wrap_inner">
    <div class="maincontent" id="div_new">

        <div class="OurContentFull">


            <?php

            $data = Costumerassociationdetails0::find_by_plan_id($_GET['id']);
            $data1 = Plandetails1::find_by_id($_GET['id']);
            $data2 = Moreplandetails::find_by_plan_id($_GET['id']);
            $data3 = Costumerassociationdetails::find_by_post_plan_id(1, $_GET['id']);
            $data3_1 = Costumerassociationdetails::find_by_post_plan_id(2, $_GET['id']);
            $data3_2 = Costumerassociationdetails::find_by_post_plan_id(4, $_GET['id']);
            $fiscal = FiscalYear::find_by_id($data1->fiscal_id);
            $print_history = PrintHistory::find_by_url_plan_id_and_letter_type(6,$_GET['id'],'दररेट पेश गर्न कम्पनी/निर्माण व्यवसायीलाई लेखेको पत्र');

            ?>

                <div class=""><input type="hidden" name="id" value="<?= $_GET['id'] ?>"/>

                <div class="userprofiletable">
                    <div class="printPage">
                        <div class="printlogo"><img src="images/janani.png" alt="Logo"></div>
                        <?php include("menuincludes/letter_head.php");?>
                        <div class="myspacer"></div>
                        <div class="printContent">
                            <div class="mydate">मिति :  <?php echo convertedcit($date_selected); ?>
                            </div>
                            <div class="patrano">पत्र संख्या :<?= convertedcit($fiscal->year) ?> </div>
                            <div class="chalanino">योजना दर्ता नं : <?php echo convertedcit($_GET['id']) ?></div>
                            <div class="chalanino">च न. :</div>
                            <div class="subject"><u>विषय:- दरभाउ पत्र छनौट सम्बन्धमा ।</u></div>
                            <div class="myspacer20"></div>
                            <div class="bankname"> श्रीमान् </div>
                            <div class="bankaddress"></div>
                            <div class="myspacer"></div>
                            <div class="banktextdetails">
                               <strong><?= SITE_LOCATION; ?> </strong>को मिति 
                                <?= convertedcit($print_date->nepali_date) ?> मा माग गरेको कोटेसन पत्र
                                बमोजिम <strong><?= $data1->program_name ?> </strong>योजना/सामग्री खरीद गर्न/कार्य गर्न सम्बन्धित निर्माण
                                व्यवसायी/कम्पनी/फर्मबाट देहाय बमोजिमको कोटेसन यस कार्यालयमा प्राप्त भयो ।
                            </div>
                            <div class="myspacer"></div>
                                <table class="table-bordered myWidth100">
                                    <tr>
                                        <th rowspan="2">विवरण</th>
                                        <th colspan="5" style="text-align: center;">पेश भएको दररेट रु.
                                        </th>
                                    </tr>
                                    <tr>
                                        <th>जम्मा मूल्य रु.</th>
                                        <th>मू.अ. कर रु.</th>
                                        <th>कन्टेन्जेन्सी/ढुवानी रु.</th>
                                        <th>कूल जम्मा रु.</th>
                                        <th>कैफियत</th>
                                    </tr>
                                    <?php foreach ($quotation_enlist as $enlist):
                                        if ($enlist->enlist_type == 10) {
                                            $en = Contractordetails::find_by_id($enlist->enlist_id);
                                            $name = $en->contractor_name;
                                            $type = 'निर्माण ब्यवोसायी';

                                        } else {
                                            $en = Enlist::find_by_id($enlist->enlist_id);
                                            $name_type = 'name' . $enlist->enlist_type;
                                            $name = $en->$name_type;
                                            switch ($en->type) {
                                                case 0:
                                                    $type = 'फर्म/कम्पनी';
                                                    break;
                                                case 1:
                                                    $type = 'कर्मचारी';
                                                    break;
                                                case 2:
                                                    $type = 'संस्था';
                                                    break;
                                                case 3:
                                                    $type = 'पदाधिकारी';
                                                    break;
                                                case 4:
                                                    $type = 'अन्य समूह ';
                                                    break;
                                                case 5:
                                                    $type = 'उपभोक्ता समिति';
                                                    break;
                                                default:
                                                    $type = "";
                                            }

                                        }
                                        if ($enlist->is_vat == 1) {
                                            $vat = $enlist->amount - ($enlist->amount / 1.13);
                                            $enlist_amount = $enlist->amount/1.13;
                                            $sum = $enlist_amount + $enlist->extra_amount + $vat;
                                            // $name = "मु.अ कर सहित";
                                        } else {
                                            $vat = ($enlist->amount * 1.13) - ($enlist->amount);
                                            $enlist_amount = $enlist->amount;
                                            $sum = $enlist->amount + $enlist->extra_amount + $vat;
                                            // $name = "";
                                        }
                                        $sum_array[$enlist->id] = $sum;
                                        ?>
                                        <tr>
                                            <th><?= $name . '( ' . $type . ' )' ?></th>
                                            <th><?= convertedcit(placeholder($enlist->amount)) ?></th>
                                            <th><?= convertedcit(placeholder(round($vat,2))) ?></th>
                                            <th><?= convertedcit(placeholder($enlist->extra_amount)) ?></th>
                                            <th><?= convertedcit(placeholder($sum)) ?></th>
                                            <th><?= $enlist->remarks ?></th>

                                        </tr>
                                    <?php endforeach;
                                    $maxs = array_keys($sum_array, min($sum_array));
                                    $max_id = $maxs[0];
                                    $max_enlist = Quotationenlist::find_by_id($max_id);
                                    $max_value = min($sum_array);
                                    //new
                                    if ($max_enlist->enlist_type == 10) {
                                        $en1 = Contractordetails::find_by_id($max_enlist->enlist_id);
                                        $name1 = $en1->contractor_name;
                                        
                                        $type1 = 'निर्माण ब्यवोसायी';

                                    } else {
                                        $en1 = Enlist::find_by_id($max_enlist->enlist_id);
                                        $name_type1 = 'name' . $max_enlist->enlist_type;
                                        $name1 = $en1->$name_type;
                                        switch ($en1->type) {
                                            case 0:
                                                $type1 = 'फर्म/कम्पनी';
                                                break;
                                            case 1:
                                                $type1 = 'कर्मचारी';
                                                break;
                                            case 2:
                                                $type1 = 'संस्था';
                                                break;
                                            case 3:
                                                $type1 = 'पदाधिकारी';
                                                break;
                                            case 4:
                                                $type1 = 'अन्य समूह ';
                                                break;
                                            case 5:
                                                $type1 = 'उपभोक्ता समिति';
                                                break;
                                            default:
                                                $type1 = "";
                                        }

                                    }
                                    ?>
                                </table>
                                <div class="myspacer"></div>
                               श्रीमान्
                               <br>
                                उपरोक्तानुसार पेश भएकोमा सबै भन्दा घटी दररेट श्री <strong><?=$name1?></strong>
                               को रु. (मु.अ. कर सहित)
                               रु. 
                               <strong><?=convertedcit($max_value);?></strong>
                               <strong>(अक्षरेपी रु . 
                               <?=convert($max_value)?></strong>
                               पेश हुन आएको हुँदा  सार्बजनिक खरिद ऐन, २०६३ को दफा ४१ र निवमावली को ८५  को उपनियम
                               ४ बमोजिम
                               सारभूत रुपमा प्रभावग्राही देखिएको श्री 
                               <strong><?=$name1?></strong>
                               बाट पेश भएको दररेट स्वीकृत गरि निज संग सम्झौता गरि  कार्यदेश दिन निर्णयार्थ पेश गरेको छु /
                               )</strong>

                            </div>
                            <div class="myspacer20"></div>
                            <div class="oursignature mymarginright" > सदर गर्ने <br>
                                <?php
                                if(!empty($worker1))
                                {
                                    echo $worker1->authority_name."<br/>";
                                    echo $worker1->post_name;
                                }
                                ?>
                            </div>
                            <div class="oursignatureleft mymarginright"> तयार गर्ने  <br/>
                                <?php
                                if(!empty($worker2))
                                {
                                    echo $worker2->authority_name."<br/>";
                                    echo $worker2->post_name;
                                }
                                ?>
                            </div>
                            <div class="oursignatureleft mymarginright" style="margin-left: 7em;"> योजना शाखा   <br/>
                                <?php
                                if(!empty($worker3))
                                {
                                    echo $worker3->authority_name."<br/>";
                                    echo $worker3->post_name;
                                }
                                ?>
                            </div>
                            <div class="myspacer"></div>

        </div>

        <div class="myspacer"></div>
    </div>
    <!--<div class="settingsMenu1"><a href="settings_topic_add_sub.php">सह शिर्षक थप्नुहोस +</a></div>-->
</div>
</div>
</div>
</div><!-- main menu ends -->


</div><!-- top wrap ends -->



