<?php require_once ("includes/initialize.php");
if (!$session->is_logged_in()) {
  redirect_to("logout.php");
}
$mode = getUserMode();
error_reporting(1);
$counted_result = getOnlyRegisteredPlans($_GET['ward_no']);
if ($mode != "administrator" && $mode != "superadmin" && $mode != "user") {
  die("ACCESS DENIED");
}
if ($_GET['ward_no'] == '') {
  $ward_name = " 0 ( पालिका स्तरीय )";
} else {
  $ward_name = convertedcit($_GET['ward_no']);
}
if (!empty($_POST['search'])) {
  if (isset($_POST['search'])) {
    if ($_POST['b_id'] != 0) {
      $final_array1 = $counted_result['count_array'];
      $result = array(); // Initialize an empty array to store results
      $result0 = Plandetails1::find_by_plan_id(implode(",", $final_array1));
      $title = "<div style='color:black;'> तपाई अहिले वडा नं.<u><b>" . $ward_name . "</b></u> को <u><b>" . Topicareaagreement::getName($_POST['b_id']) . "</b></u> मार्फत दर्ता भयको योजनाको विवरण हेर्दै हुनुहुन्छ !!! </div>";
      if (!empty($result0)) {
        foreach ($result0 as $r0) {
          $data = Plandetails1::find_by_sql("SELECT * FROM plan_details1 WHERE id=" . $r0->id . " AND topic_area_agreement_id=" . $_POST['b_id']);
          if (!empty($data)) {
            $result = array_merge($result, $data); // Merge data into result array
          }
        }
      }
    } else {
      $final_array1 = $counted_result['count_array'];
      $result = Plandetails1::find_by_plan_id(implode(",", $final_array1));
      $title = "<div style='color:yellow;'>तपाई अहिले वडा नं. <u><b>" . $ward_name . "</b></u> मा दर्ता भयको योजनाको विवरण हेर्दै हुनुहुन्छ !!!</div>";
    }
  }
} else {
  $final_array1 = $counted_result['count_array'];
  $result = Plandetails1::find_by_plan_id(implode(",", $final_array1));
  $title = "<div style='color:yellow;'>तपाई अहिले वडा नं. <u><b>" . $ward_name . "</b></u> मा दर्ता भयको योजनाको विवरण हेर्दै हुनुहुन्छ !!!</div>";
}
// echo "<pre>";
// print_r($result);


$count1 = count($final_array1);
$total_investment1 = Plandetails1::get_total_investment_by_plan_ids(implode(",", $final_array1));
$anudan = Topicareaagreement::find_all();
include ("menuincludes/header.php");
?>
<style>
  table {

    width: 100%;
    border: none;
  }

  th,
  td {
    padding: 8px;
    text-align: left;
    border-bottom: 3px solid #ddd;
  }

  tr:nth-child(even) {
    background-color: #f2f2f2;
  }

  tr:hover {
    background-color: #f5f5f5;
  }
</style>

<body>
  <?php include ("menuincludes/topwrap.php"); ?>
  <div id="body_wrap_inner">

    <div class="maincontent">
      <h2 class="headinguserprofile">दर्ता भएको तर कुनै विवरण नभरिएको रिपोर्ट हेर्नुहोस | <a href="report.php"
          class="btn">पछि जानुहोस </a>|
        <a href="view_report1_excel.php?ward_no=<?= $_GET['ward_no'] ?>&b_id=<?= $_POST['b_id'] ?>" class="btn">Excel
          Export</a> |
        <a target="_blank" href="view_report1_print.php?ward_no=<?= $_GET['ward_no'] ?>&b_id=<?= $_POST['b_id'] ?>"
          class="btn">Print</a>
      </h2>

      <div class="myMessage"><?php echo $message; ?></div>
      <div class="OurContentFull">
        <form method="post" enctype="multipart/form-data">
          <div class="card" style="width:50%;margin-left:365px;">
            <div class="card-header text-center">अनुदान किसिम छानुहोस</div>
            <div class="card-body">
              <div class="titleInput">अनुदान (बजेट) शिर्षक छानुहोस</div>
              <div class="newInput">
                <select class="form-control select2" name="b_id">
                  <option value="0">--छान्नुहोस्--</option>
                  <?php foreach ($anudan as $an): ?>
                    <option value="<?= $an->id ?>" <?php if ($an->id == $_POST['b_id']) {
                        echo 'selected="selected"';
                      } ?>>
                      <?= $an->name; ?>
                    </option>
                  <?php endforeach; ?>
                </select>
              </div>
            </div>
            <div class="card-footer text-center">
              <input type="submit" class="btn" name="search" value="खोज्नुहोस">
            </div>
          </div>
        </form>


        <!--<h2>बिषयगत क्षेत्रको नाम </h2>-->
        <div class="userprofiletable">
          <div class="">
            <h2><?= $title ?></h2>
          </div>
          <table class="table table-bordered table-hover">
            <tr>
              <td class="myCenter"><strong>सि. नं.</strong></td>
              <td class="myCenter"><strong>दर्ता नं</strong></td>
              <td class="myCenter"><strong>योजनाको नाम</strong></td>
              <td class="myCenter"><strong>योजनाको बिषयगत क्षेत्रको किसिम</strong></td>
              <td class="myCenter"><strong>योजनाको शिर्षकगत किसिम</strong></td>
              <td class="myCenter"><strong>योजनाको उपशिर्षकगत किसिम</strong></td>
              <td class="myCenter"><strong>योजनाको विनियोजन किसिम</strong></td>
              <td class="myCenter"><strong>वार्ड नं</strong></td>
              <td class="myCenter"><strong>अनुदान रु </strong></td>
              <td class="myCenter">हाल सम्म लागेको भुक्तानी</td>
              <td class="myCenter"><strong>कुल बाँकी रकम</strong></td>
              <td class="myCenter"><strong>विवरण हेर्नुहोस</strong> </td>
            </tr>
            <?php $i = 1;
            $total_net_payable_amount = "";
            $total_remaining_amount = "";
            foreach ($result as $data):
              $samiti_plan_total = Samitiplantotalinvestment::find_by_plan_id($data->id);
              $contract_plan_total = Contract_total_investment::find_by_plan_id($data->id);
              $amanat_lagat = AmanatLagat::find_by_plan_id($data->id);
              $net_payable_amount = 0;
              $remaining_amount = $data->investment_amount;
              if ($data->type == 1) {
                $link = "program_total_view.php?id=" . $data->id;
              } elseif ($data->type == 0 && !empty($samiti_plan_total)) {
                $link = "view_samiti_plan_form.php?id=" . $data->id;
              } elseif ($data->type == 0 && !empty($contract_plan_total)) {
                $link = "view_all_contract.php?id=" . $data->id;
              } elseif ($data->type == 0 && !empty($amanat_lagat)) {
                $link = "view_all_amanat.php?id=" . $data->id;
              } else {
                $link = "view_plan_form.php?id=" . $data->id;
              }
              ?>
              <tr>
                <td class="myCenter"><?php echo convertedcit($i); ?></td>
                <td class="myCenter"><?php echo convertedcit($data->id); ?></td>
                <td class="myCenter"><?php echo $data->program_name; ?></td>
                <td class="myCenter"><?php echo Topicarea::getName($data->topic_area_id); ?></td>
                <td class="myCenter"><?php echo Topicareatype::getName($data->topic_area_type_id); ?></td>
                <td class="myCenter"><?php echo Topicareatypesub::getName($data->topic_area_type_sub_id); ?></td>
                <td class="myCenter"><?php echo Topicareainvestment::getName($data->topic_area_investment_id); ?></td>
                <td class="myCenter"><?php echo convertedcit($data->ward_no); ?></td>
                <td class="myCenter"><?php echo convertedcit($data->investment_amount); ?></td>
                <td class="myCenter"><?php echo convertedcit($net_payable_amount); ?></td>
                <td class="myCenter"><?php echo convertedcit($remaining_amount); ?></td>
                <td class="myCenter"><a href="<?= $link ?>" class="btn">पुरा विवरण हेर्नुहोस</a></td>
              </tr>
              <?php $i++;
              $total_net_payable_amount += $net_payable_amount;
              $total_remaining_amount += $remaining_amount;
            endforeach; ?>
            <tr>
              <td colspan="7">&nbsp; </td>
              <td>जम्मा </td>
              <td><?php echo convertedcit(placeholder($total_investment1)); ?></td>
              <td><?php echo convertedcit(placeholder($total_net_payable_amount)); ?></td>
              <td colspan="2"><?php echo convertedcit(placeholder($total_remaining_amount)); ?></td>
            </tr>
          </table>

        </div>
      </div>
    </div><!-- main menu ends -->

  </div><!-- top wrap ends -->
  <?php include ("menuincludes/footer.php"); ?>