<?php
include_once('includes/initialize.php');

$settingbhautikPariman = SettingbhautikPariman::find_by_id($_POST['id']);
$unitname = Units::find_by_id($settingbhautikPariman->unit_name);
$select = "";
$select .= "<select name='unit_id[]'>";
$select .= "<option value='".$unitname->id."'>".$unitname->name."</option>";
$select .= "</select>";
echo json_encode($select);
exit;
?>
