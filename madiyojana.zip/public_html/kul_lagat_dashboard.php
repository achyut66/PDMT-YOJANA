<?php require_once("includes/initialize.php"); ?>

<?php
	if(!$session->is_logged_in()){ redirect_to("logout.php");}
?>

<!-- js ends -->
<title>योजना संचालन प्रकृया :: <?php echo SITE_SUBHEADING;?></title>
<style>
#rcorners1 {
  border-radius: 25px;
  background: #87CEEB;
  padding: 40px; 
  width: 350px;
  height: 150px;  
  color: black;
}
</style>
</head>
<?php 
include("menuincludes/topwrap.php");
include("menuincludes/header.php"); 
?>
<body>
    <div id="body_wrap_inner"> 
    <div class="col col-lg-12 col-md-12 col-sm-12 col-xs-12 maincontent">
        <div class="myspacer30"></div>
                    <h2 class="dashboard">योजनाको कुल लागत अनुमान / फोटो हाल्नुहोस | <a href="upabhoktasamitidashboard.php" class="btn"> पछि जानुहोस </a></h2>
                        <div class="myspacer"></div>
                    <div class="container">
                          <div class="col-md-12" style="margin-left: 170px;">
                              <div class="row">
                                    <div class="col-md-4">
                                    <a href="plan_form1.php" target="_blank">
                                        <p id="rcorners1" class="text-center" style="font-size: 22px;">योजनाको कुल लागत<br>
                                        <img src="images/n/lagat1.png" alt="Upabhokta Icon" class="dashimg" />
                                    </p>
                                    </a>
                                    </div>
                                    <div class="col-md-4">
                                    <a href="photos_upload.php" target="_blank">
                                        <p id="rcorners1" class="text-center" style="font-size: 22px;">फोटो Upload गर्नुहोस<br>
                                        <img src="images/n/photo.png" alt="Upabhokta Icon" class="dashimg" />
                                    </p>
                                    </a>
                                    </div>
                              </div>
                          </div>
                    </div>
    </div>
    </div>   
</body>
<?php include("menuincludes/footer.php"); ?>